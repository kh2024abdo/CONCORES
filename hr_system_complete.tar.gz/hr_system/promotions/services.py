from django.db import transaction
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from datetime import date, timedelta

from employees.models import Employee, EmployeeGradeHistory
from grades.models import GradeScaleVersion, GradeScaleItem, Rank
from promotions.models import PromotionEligibility, PromotionBatch, PromotionBatchItem

User = get_user_model()


class PromotionService:
    """
    خدمة إدارة الترقيات
    تحتوي على منطق الأعمال الخاص بحساب الاستحقاق وتنفيذ الترقيات
    """
    
    def __init__(self):
        self.default_promotion_duration_months = 24  # مدة افتراضية للترقية (سنتين)
    
    @transaction.atomic
    def promote_employee(
        self,
        employee: Employee,
        new_grade_number: int,
        grade_scale_version: GradeScaleVersion,
        promotion_date: date,
        decision_number: str,
        decision_date: date,
        promoted_by_id: int = None,
        notes: str = ""
    ) -> PromotionBatchItem:
        """
        ترقية موظف إلى درجة جديدة
        
        Args:
            employee: الموظف المراد ترقيته
            new_grade_number: رقم الدرجة الجديدة
            grade_scale_version: إصدار شبكة الأرقام الاستدلالية
            promotion_date: تاريخ الترقية
            decision_number: رقم المقرر
            decision_date: تاريخ المقرر
            promoted_by_id: ID المستخدم الذي نفذ الترقية
            notes: ملاحظات
            
        Returns:
            PromotionBatchItem: سجل الترقية
            
        Raises:
            ValidationError: إذا كانت البيانات غير صحيحة
        """
        
        # 1. التحقق من صحة الدرجة الجديدة
        if new_grade_number <= employee.current_grade_number:
            raise ValidationError(
                f"الدرجة الجديدة ({new_grade_number}) يجب أن تكون أكبر من الدرجة الحالية ({employee.current_grade_number})"
            )
        
        # 2. التحقق من وجود الدرجة في الشبكة
        try:
            scale_item = GradeScaleItem.objects.get(
                version=grade_scale_version,
                grade_number=new_grade_number
            )
        except GradeScaleItem.DoesNotExist:
            raise ValidationError(
                f"الدرجة {new_grade_number} غير موجودة في شبكة الأرقام الاستدلالية '{grade_scale_version.name}'"
            )
        
        # 3. التحقق من الرتبة الحالية للموظف
        if not employee.current_rank:
            raise ValidationError("الموظف لا يملك رتبة حالية")
        
        # التحقق من أن الدرجة الجديدة ضمن نطاق الرتبة
        if new_grade_number > employee.current_rank.max_grade:
            raise ValidationError(
                f"الدرجة {new_grade_number} تتجاوز الحد الأقصى لرتبة الموظف ({employee.current_rank.max_grade})"
            )
        
        # 4. الحصول على الصنف المرتبط بالموظف
        category = employee.current_rank.category
        
        # 5. إنشاء سجل الترقية مباشرة كعنصر ترقية
        promoted_by = User.objects.get(id=promoted_by_id) if promoted_by_id else None
        
        record = PromotionBatchItem.objects.create(
            # ننشئ دفعة فردية تلقائياً إذا لم توجد
            batch=self._get_or_create_batch_for_promotion(
                year=promotion_date.year,
                decision_number=decision_number,
                decision_date=decision_date,
                created_by=promoted_by
            ),
            employee=employee,
            old_grade=employee.current_grade_number,
            new_grade=new_grade_number,
            category=category,
            old_index=employee.current_index_value,
            new_index=scale_item.index_value,
            effective_date=promotion_date,
            notes=notes
        )
        
        # 6. تحديث بيانات الموظف الحالية
        employee.current_grade_number = new_grade_number
        employee.current_index_value = scale_item.index_value
        employee.grade_start_date = promotion_date
        employee.save(update_fields=[
            'current_grade_number',
            'current_index_value',
            'grade_start_date',
            'updated_at'
        ])
        
        # 7. إنشاء سجل في تاريخ الدرجات
        EmployeeGradeHistory.objects.create(
            employee=employee,
            grade_number=new_grade_number,
            index_value=scale_item.index_value,
            start_date=promotion_date,
            decision_number=decision_number,
            decision_date=decision_date,
            created_by=promoted_by
        )
        
        # 8. تحديث حالة الاستحقاق
        try:
            eligibility = PromotionEligibility.objects.filter(
                employee=employee,
                year=promotion_date.year,
                status__in=['PENDING', 'ELIGIBLE', 'UPCOMING']
            ).first()
            
            if eligibility:
                eligibility.status = 'PROMOTED'
                eligibility.is_processed = True
                eligibility.processed_date = promotion_date
                eligibility.processed_by = promoted_by
                eligibility.save(update_fields=['status', 'is_processed', 'processed_date', 'processed_by', 'updated_at'])
        except PromotionEligibility.DoesNotExist:
            pass
        
        return record
    
    def _get_or_create_batch_for_promotion(self, year: int, decision_number: str, decision_date: date, created_by=None) -> PromotionBatch:
        """الحصول على دفعة أو إنشاء واحدة للترقية"""
        batch_name = f"ترقيات {year} - {decision_number}"
        
        batch, created = PromotionBatch.objects.get_or_create(
            name=batch_name,
            year=year,
            defaults={
                'status': 'PUBLISHED',
                'decision_number': decision_number,
                'decision_date': decision_date,
                'created_by': created_by
            }
        )
        
        if not created and not batch.decision_number:
            batch.decision_number = decision_number
            batch.decision_date = decision_date
            batch.save(update_fields=['decision_number', 'decision_date'])
        
        return batch
    
    def calculate_eligibility(self, employee: Employee, reference_date: date = None) -> dict:
        """
        حساب استحقاق الموظف للترقية
        
        Args:
            employee: الموظف
            reference_date: تاريخ المرجع للحساب (افتراضياً اليوم)
            
        Returns:
            dict: معلومات الاستحقاق
        """
        if reference_date is None:
            reference_date = date.today()
        
        current_grade = employee.current_grade_number
        grade_start = employee.grade_start_date
        
        if not grade_start:
            return {
                'is_eligible': False,
                'reason': 'لا يوجد تاريخ لبداية الدرجة الحالية',
                'seniority_days': 0,
                'required_months': self.default_promotion_duration_months,
                'next_promotion_date': None
            }
        
        # حساب الأقدمية بالأيام
        seniority_days = (reference_date - grade_start).days
        seniority_months = seniority_days // 30
        
        # المدة المطلوبة للترقية (يمكن جعلها قابلة للتكوين حسب الرتبة/الصنف)
        required_months = self.default_promotion_duration_months
        
        # تاريخ الاستحقاق المتوقع
        expected_date = grade_start + timedelta(days=required_months * 30)
        
        is_eligible = seniority_months >= required_months
        
        # التحقق من الدرجة القصوى
        max_grade_reached = False
        if employee.current_rank:
            if current_grade >= employee.current_rank.max_grade:
                max_grade_reached = True
                is_eligible = False
        
        return {
            'is_eligible': is_eligible,
            'max_grade_reached': max_grade_reached,
            'current_grade': current_grade,
            'next_grade': current_grade + 1 if not max_grade_reached else None,
            'seniority_days': seniority_days,
            'seniority_months': seniority_months,
            'required_months': required_months,
            'remaining_months': max(0, required_months - seniority_months),
            'next_promotion_date': expected_date if not is_eligible and not max_grade_reached else None,
            'grade_start_date': grade_start,
            'reference_date': reference_date
        }
    
    @transaction.atomic
    def batch_calculate_eligibility(self, reference_date: date = None) -> int:
        """
        حساب الاستحقاق لجميع الموظفين وإنشاء سجلات الاستحقاق
        
        Args:
            reference_date: تاريخ المرجع
            
        Returns:
            int: عدد سجلات الاستحقاق التي تم إنشاؤها
        """
        if reference_date is None:
            reference_date = date.today()
        
        employees = Employee.objects.filter(
            employment_status='ACTIVE',
            current_grade_number__lt=13  # ليس في أقصى درجة
        )
        
        created_count = 0
        
        for emp in employees:
            eligibility_data = self.calculate_eligibility(emp, reference_date)
            
            if eligibility_data['max_grade_reached']:
                continue
            
            # إنشاء أو تحديث سجل الاستحقاق
            obj, created = PromotionEligibility.objects.update_or_create(
                employee=emp,
                year=reference_date.year,
                category=emp.current_rank.category if emp.current_rank else None,
                defaults={
                    'current_grade': eligibility_data['current_grade'],
                    'next_grade': eligibility_data['next_grade'],
                    'seniority_months': eligibility_data['seniority_months'],
                    'required_months': eligibility_data['required_months'],
                    'eligibility_date': eligibility_data['next_promotion_date'],
                    'is_eligible': eligibility_data['is_eligible'],
                    'status': 'ELIGIBLE' if eligibility_data['is_eligible'] else 'NEAR_ELIGIBLE',
                    'calculated_at': timezone.now()
                }
            )
            
            if created:
                created_count += 1
        
        return created_count
    
    def get_eligible_employees(self, year: int = None, department_id: int = None, rank_id: int = None) -> list:
        """
        الحصول على قائمة الموظفين المستحقين للترقية
        
        Args:
            year: السنة
            department_id: ID المديرية للتصفية
            rank_id: ID الرتبة للتصفية
            
        Returns:
            list: قائمة الموظفين المستحقين
        """
        if year is None:
            year = date.today().year
        
        queryset = PromotionEligibility.objects.filter(
            year=year,
            is_eligible=True,
            status__in=['ELIGIBLE', 'PENDING']
        ).select_related('employee', 'employee__structure', 'employee__current_rank')
        
        if department_id:
            queryset = queryset.filter(employee__structure_id=department_id)
        
        if rank_id:
            queryset = queryset.filter(employee__current_rank_id=rank_id)
        
        return queryset.order_by('employee__last_name', 'employee__first_name')
