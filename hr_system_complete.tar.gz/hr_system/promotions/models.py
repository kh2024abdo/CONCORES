"""
Promotions App Models
نظام الترقيات وإدارة الاستحقاقات
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import SoftDeleteModel
from employees.models import Employee
from grades.models import Category, Rank


class PromotionStatus(models.TextChoices):
    """حالات الترقية"""
    NOT_ELIGIBLE = 'not_eligible', _('غير مستحق')
    NEAR_ELIGIBLE = 'near_eligible', _('قريب الاستحقاق')
    ELIGIBLE = 'eligible', _('مستحق')
    PENDING = 'pending', _('قيد المعالجة')
    APPROVED = 'approved', _('تمت الموافقة')
    PROMOTED = 'promoted', _('تمت الترقية')
    SUSPENDED = 'suspended', _('موقوف')
    REJECTED = 'rejected', _('مرفوض')


class PromotionBatch(SoftDeleteModel):
    """
    دفعة ترقيات - مجموعة من الترقيات المعالجة معاً
    """
    title_ar = models.CharField(_('العنوان بالعربية'), max_length=200)
    title_fr = models.CharField(_('العنوان بالفرنسية'), max_length=200, blank=True)
    title_en = models.CharField(_('العنوان بالإنجليزية'), max_length=200, blank=True)
    
    promotion_year = models.PositiveIntegerField(_('سنة الترقية'))
    decision_date = models.DateField(_('تاريخ القرار'), null=True, blank=True)
    decision_number = models.CharField(_('رقم القرار'), max_length=100, blank=True)
    
    status = models.CharField(
        _('الحالة'),
        max_length=20,
        choices=PromotionStatus.choices,
        default=PromotionStatus.PENDING
    )
    
    notes = models.TextField(_('ملاحظات'), blank=True)
    is_processed = models.BooleanField(_('تمت المعالجة'), default=False)
    processed_at = models.DateTimeField(_('تاريخ المعالجة'), null=True, blank=True)
    
    processed_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='processed_promotion_batches',
        verbose_name=_('تمت المعالجة بواسطة')
    )
    
    class Meta:
        verbose_name = _('دفعة ترقيات')
        verbose_name_plural = _('دفعات الترقيات')
        ordering = ['-promotion_year', '-created_at']
    
    def __str__(self):
        return f"{self.title_ar} ({self.promotion_year})"
    
    @property
    def promoted_count(self):
        return self.promotions.filter(status=PromotionStatus.PROMOTED).count()
    
    @property
    def total_count(self):
        return self.promotions.count()


class PromotionEligibilityQuerySet(models.QuerySet):
    """Manager مخصص للاستعلام عن الموظفين المستحقين للترقية"""
    
    def eligible(self, days_threshold=30):
        from django.utils import timezone
        today = timezone.now().date()
        return self.filter(status=PromotionStatus.ELIGIBLE, eligibility_date__lte=today)
    
    def near_eligible(self, days_ahead=30):
        from django.utils import timezone
        from datetime import timedelta
        today = timezone.now().date()
        future_date = today + timedelta(days=days_ahead)
        return self.filter(
            status__in=[PromotionStatus.NEAR_ELIGIBLE, PromotionStatus.ELIGIBLE],
            eligibility_date__gt=today,
            eligibility_date__lte=future_date
        )
    
    def delayed(self):
        from django.utils import timezone
        today = timezone.now().date()
        return self.filter(
            status=PromotionStatus.ELIGIBLE,
            eligibility_date__lt=today,
            promotion_date__isnull=True
        )


class PromotionManager(models.Manager):
    def get_queryset(self):
        return PromotionEligibilityQuerySet(self.model, using=self._db)
    
    def eligible(self, days_threshold=30):
        return self.get_queryset().eligible(days_threshold)
    
    def near_eligible(self, days_ahead=30):
        return self.get_queryset().near_eligible(days_ahead)
    
    def delayed(self):
        return self.get_queryset().delayed()


class Promotion(SoftDeleteModel):
    """
    ترقية موظف - سجل ترقية فردي لموظف
    """
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='promotions',
        verbose_name=_('الموظف')
    )
    
    batch = models.ForeignKey(
        PromotionBatch,
        on_delete=models.CASCADE,
        related_name='promotions',
        null=True,
        blank=True,
        verbose_name=_('الدفعة')
    )
    
    from_grade_number = models.PositiveIntegerField(_('الدرجة السابقة'))
    to_grade_number = models.PositiveIntegerField(_('الدرجة الجديدة'))
    
    rank = models.ForeignKey(
        Rank,
        on_delete=models.CASCADE,
        related_name='promotions',
        verbose_name=_('الرتبة')
    )
    
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='promotions',
        verbose_name=_('الصنف')
    )
    
    status = models.CharField(
        _('الحالة'),
        max_length=20,
        choices=PromotionStatus.choices,
        default=PromotionStatus.PENDING
    )
    
    eligibility_date = models.DateField(_('تاريخ الاستحقاق'))
    promotion_date = models.DateField(_('تاريخ الترقية'), null=True, blank=True)
    delay_days = models.PositiveIntegerField(_('التأخير (أيام)'), default=0)
    
    previous_index = models.DecimalField(
        _('الرقم الاستدلالي السابق'),
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True
    )
    
    new_index = models.DecimalField(
        _('الرقم الاستدلالي الجديد'),
        max_digits=6,
        decimal_places=2
    )
    
    decision_number = models.CharField(_('رقم القرار'), max_length=100, blank=True)
    decision_date = models.DateField(_('تاريخ القرار'), null=True, blank=True)
    notes = models.TextField(_('ملاحظات'), blank=True)
    grade_history_created = models.BooleanField(_('تم إنشاء سجل الدرجة'), default=False)
    
    objects = PromotionManager()
    
    class Meta:
        verbose_name = _('ترقية')
        verbose_name_plural = _('الترقيات')
        ordering = ['-eligibility_date', '-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['eligibility_date']),
            models.Index(fields=['employee', 'status']),
        ]
    
    def __str__(self):
        return f"{self.employee} - Grade {self.from_grade_number} to {self.to_grade_number}"
    
    def save(self, *args, **kwargs):
        if self.promotion_date and self.eligibility_date:
            self.delay_days = (self.promotion_date - self.eligibility_date).days
            if self.delay_days < 0:
                self.delay_days = 0
        super().save(*args, **kwargs)


class PromotionCandidate(SoftDeleteModel):
    """
    مرشح للترقية - يستخدم لتتبع الموظفين المرشحين قبل الموافقة النهائية
    """
    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='promotion_candidateships',
        verbose_name=_('الموظف')
    )
    
    current_grade_number = models.PositiveIntegerField(_('الدرجة الحالية'))
    proposed_grade_number = models.PositiveIntegerField(_('الدرجة المقترحة'))
    
    rank = models.ForeignKey(
        Rank,
        on_delete=models.CASCADE,
        related_name='candidate_ranks',
        verbose_name=_('الرتبة')
    )
    
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='candidate_categories',
        verbose_name=_('الصنف')
    )
    
    expected_eligibility_date = models.DateField(_('تاريخ الاستحقاق المتوقع'))
    seniority_days = models.PositiveIntegerField(_('الأقدمية (أيام)'), default=0)
    
    status = models.CharField(
        _('الحالة'),
        max_length=20,
        choices=PromotionStatus.choices,
        default=PromotionStatus.NOT_ELIGIBLE
    )
    
    conditions_verified = models.BooleanField(_('تم التحقق من الشروط'), default=False)
    verification_notes = models.TextField(_('ملاحظات التحقق'), blank=True)
    
    proposed_batch = models.ForeignKey(
        PromotionBatch,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='candidates',
        verbose_name=_('الدفعة المقترحة')
    )
    
    objects = PromotionManager()
    
    class Meta:
        verbose_name = _('مرشح للترقية')
        verbose_name_plural = _('المرشحون للترقية')
        ordering = ['expected_eligibility_date', 'employee__last_name']
        unique_together = ['employee', 'proposed_grade_number', 'status']
        indexes = [
            models.Index(fields=['status', 'expected_eligibility_date']),
            models.Index(fields=['employee', 'status']),
        ]
    
    def __str__(self):
        return f"{self.employee} - Grade {self.current_grade_number} to {self.proposed_grade_number}"
