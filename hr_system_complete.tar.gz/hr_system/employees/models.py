from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import SoftDeleteModel, TimeStampedModel
from organization.models import Structure
from grades.models import Rank, Category

class Employee(SoftDeleteModel, TimeStampedModel):
    """
    نموذج الموظف - المحور الرئيسي للنظام
    يحتوي على البيانات الأساسية الثابتة للموظف
    """

    # === المعرفات ===
    nin = models.CharField(_("NIN (National ID)"), max_length=20, unique=True, db_index=True)
    matricule = models.CharField(_("Matricule"), max_length=20, unique=True, db_index=True)
    internal_id = models.CharField(_("Internal ID"), max_length=20, blank=True, db_index=True)

    # === الأسماء (متعددة اللغات) ===
    last_name = models.CharField(_("Last Name (FR)"), max_length=100)
    first_name = models.CharField(_("First Name (FR)"), max_length=100)
    last_name_ar = models.CharField(_("Last Name (AR)"), max_length=100, blank=True)
    first_name_ar = models.CharField(_("First Name (AR)"), max_length=100, blank=True)
    maiden_name = models.CharField(_("Maiden Name (FR)"), max_length=100, blank=True)
    maiden_name_ar = models.CharField(_("Maiden Name (AR)"), max_length=100, blank=True)

    # === المعلومات الشخصية ===
    GENDER_CHOICES = [('M', _("Male")), ('F', _("Female"))]
    gender = models.CharField(_("Gender"), max_length=1, choices=GENDER_CHOICES)
    date_of_birth = models.DateField(_("Date of Birth"))
    place_of_birth = models.CharField(_("Place of Birth (FR)"), max_length=200)
    place_of_birth_ar = models.CharField(_("Place of Birth (AR)"), max_length=200, blank=True)
    nationality = models.CharField(_("Nationality"), max_length=100, default="DZ")

    FAMILY_STATUS_CHOICES = [('SINGLE', _("Single")), ('MARRIED', _("Married")), ('DIVORCED', _("Divorced")), ('WIDOWED', _("Widowed"))]
    family_status = models.CharField(_("Family Status"), max_length=20, choices=FAMILY_STATUS_CHOICES, blank=True)

    BLOOD_TYPE_CHOICES = [('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'), ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-')]
    blood_type = models.CharField(_("Blood Type"), max_length=3, choices=BLOOD_TYPE_CHOICES, blank=True)

    # === معلومات العائلة ===
    father_name = models.CharField(_("Father's Name (FR)"), max_length=100)
    father_name_ar = models.CharField(_("Father's Name (AR)"), max_length=100, blank=True)
    mother_name = models.CharField(_("Mother's Name (FR)"), max_length=100)
    mother_name_ar = models.CharField(_("Mother's Name (AR)"), max_length=100, blank=True)

    # === معلومات التوظيف ===
    recruitment_date = models.DateField(_("Recruitment Date"))
    installation_date = models.DateField(_("Installation Date"), null=True, blank=True)
    affiliation_date = models.DateField(_("Affiliation Date"), null=True, blank=True)
    social_security_number = models.CharField(_("Social Security Number"), max_length=20, blank=True)

    # === بيانات الاتصال ===
    email = models.EmailField(_("Email"), blank=True)
    phone = models.CharField(_("Phone"), max_length=20, blank=True)
    address = models.TextField(_("Address"), blank=True)

    # === معلومات إضافية ===
    photo = models.ImageField(_("Photo"), upload_to='employees/photos/', blank=True, null=True)
    rfid_card = models.CharField(_("RFID Card"), max_length=50, blank=True)
    national_service = models.CharField(_("National Service"), max_length=50, blank=True)

    # === الحالة ===
    STATUS_CHOICES = [('ACTIVE', _("Active")), ('INACTIVE', _("Inactive")), ('RETIRED', _("Retired")), ('DECEASED', _("Deceased"))]
    status = models.CharField(_("Status"), max_length=20, choices=STATUS_CHOICES, default='ACTIVE')

    # === الرتبة والدرجة الحالية ===
    current_rank = models.ForeignKey(Rank, on_delete=models.SET_NULL, null=True, blank=True, related_name='current_employees', verbose_name=_("Current Rank"))
    current_grade_number = models.PositiveIntegerField(_("Current Grade Number"), default=1, help_text=_("Current grade number (1-13)"))
    current_index_value = models.DecimalField(_("Current Index Value"), max_digits=6, decimal_places=2, null=True, blank=True, help_text=_("Current salary index value"))
    grade_start_date = models.DateField(_("Grade Start Date"), null=True, blank=True, help_text=_("Start date of current grade"))
    structure = models.ForeignKey(Structure, on_delete=models.SET_NULL, null=True, blank=True, related_name='employees', verbose_name=_("Current Structure"))

    notes = models.TextField(_("Notes"), blank=True)

    class Meta:
        verbose_name = _("Employee")
        verbose_name_plural = _("Employees")
        ordering = ['matricule']
        indexes = [models.Index(fields=['nin']), models.Index(fields=['matricule']), models.Index(fields=['status'])]

    def __str__(self):
        name = self.last_name_ar and f"{self.first_name_ar} {self.last_name_ar}" or f"{self.first_name} {self.last_name}"
        return f"{name} ({self.matricule})"

    @property
    def full_name(self):
        if self.last_name_ar and self.first_name_ar:
            return f"{self.first_name_ar} {self.last_name_ar}"
        return f"{self.first_name} {self.last_name}"

    @property
    def full_name_fr(self):
        return f"{self.first_name} {self.last_name}"


class EmployeeRankHistory(TimeStampedModel):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='rank_history')
    rank = models.ForeignKey(Rank, on_delete=models.CASCADE, related_name='employee_ranks')
    start_date = models.DateField(_("Start Date"))
    end_date = models.DateField(_("End Date"), null=True, blank=True)
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/ranks/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    is_current = models.BooleanField(_("Is Current"), default=False)

    class Meta:
        verbose_name = _("Employee Rank History")
        verbose_name_plural = _("Employee Rank Histories")
        ordering = ['-start_date']

    def __str__(self):
        return f"{self.employee} - {self.rank} ({self.start_date})"

    def save(self, *args, **kwargs):
        if self.is_current:
            EmployeeRankHistory.objects.filter(employee=self.employee, is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)


class EmployeeGradeHistory(TimeStampedModel):
    PROMOTION_METHOD_CHOICES = [('SENIORITY', _("Seniority")), ('EXAM', _("Exam")), ('CHOICE', _("Choice")), ('EXCEPTIONAL', _("Exceptional"))]

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='grade_history')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='employee_grades')
    grade_number = models.PositiveIntegerField(_("Grade Number"))
    index_value = models.DecimalField(_("Index Value"), max_digits=6, decimal_places=2)
    start_date = models.DateField(_("Start Date"))
    effect_date = models.DateField(_("Effective Date"), null=True, blank=True)
    promotion_date = models.DateField(_("Promotion Date"), null=True, blank=True)
    duration_months = models.PositiveIntegerField(_("Duration (Months)"), null=True, blank=True)
    promotion_method = models.CharField(_("Promotion Method"), max_length=20, choices=PROMOTION_METHOD_CHOICES, blank=True)
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/grades/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    is_current = models.BooleanField(_("Is Current"), default=False)

    class Meta:
        verbose_name = _("Employee Grade History")
        verbose_name_plural = _("Employee Grade Histories")
        ordering = ['-start_date']

    def __str__(self):
        return f"{self.employee} - Grade {self.grade_number} ({self.start_date})"

    def save(self, *args, **kwargs):
        if self.is_current:
            EmployeeGradeHistory.objects.filter(employee=self.employee, is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)

    @property
    def next_promotion_date(self):
        if self.duration_months and self.start_date:
            from dateutil.relativedelta import relativedelta
            return self.start_date + relativedelta(months=self.duration_months)
        return None
