from django.db import transaction
from django.utils.translation import gettext_lazy as _
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta


class EmployeeService:
    """
    خدمة إدارة الموظفين
    تحتوي على منطق الأعمال المتعلق بالموظفين
    """
    
    @staticmethod
    def get_current_rank(employee):
        """الحصول على الرتبة الحالية للموظف"""
        return employee.rank_history.filter(is_current=True).first()
    
    @staticmethod
    def get_current_grade(employee):
        """الحصول على الدرجة الحالية للموظف"""
        return employee.grade_history.filter(is_current=True).first()
    
    @staticmethod
    def get_current_assignment(employee):
        """الحصول على التوجيه الحالي للموظف"""
        return employee.assignments.filter(is_current=True).first()
    
    @staticmethod
    def get_current_legal_status(employee):
        """الحصول على الوضعية القانونية الحالية"""
        return employee.legal_statuses.filter(is_current=True).first()
    
    @staticmethod
    def get_career_timeline(employee):
        """
        الحصول على الخط الزمني للمسار المهني
        يدمج جميع الأحداث بترتيب زمني
        """
        timeline = []
        
        # إضافة أحداث الرتب
        for rank in employee.rank_history.all():
            timeline.append({
                'date': rank.start_date,
                'type': 'rank',
                'title': str(rank.rank),
                'description': f"{_('Rank')}: {rank.rank}",
                'object': rank,
            })
        
        # إضافة أحداث الدرجات
        for grade in employee.grade_history.all():
            timeline.append({
                'date': grade.start_date,
                'type': 'grade',
                'title': f"{_('Grade')} {grade.grade_number}",
                'description': f"{_('Grade')} {grade.grade_number} - {_('Index')}: {grade.index_value}",
                'object': grade,
            })
        
        # إضافة أحداث التوجيهات
        for assignment in employee.assignments.all():
            timeline.append({
                'date': assignment.start_date,
                'type': 'assignment',
                'title': str(assignment.structure),
                'description': f"{_('Assignment')}: {assignment.structure}",
                'object': assignment,
            })
        
        # إضافة أحداث الوضعيات القانونية
        for status in employee.legal_statuses.all():
            timeline.append({
                'date': status.start_date,
                'type': 'legal_status',
                'title': str(status.status_type),
                'description': f"{_('Legal Status')}: {status.status_type}",
                'object': status,
            })
        
        # إضافة أحداث المناصب العليا
        for position in employee.senior_positions.all():
            timeline.append({
                'date': position.start_date,
                'type': 'senior_position',
                'title': position.position_name_display,
                'description': f"{_('Senior Position')}: {position.position_name_display}",
                'object': position,
            })
        
        # ترتيب حسب التاريخ
        timeline.sort(key=lambda x: x['date'], reverse=True)
        
        return timeline
    
    @staticmethod
    def calculate_seniority_months(employee, grade_history=None):
        """
        حساب مدة الأقدمية بال أشهر في الدرجة الحالية
        """
        if not grade_history:
            grade_history = EmployeeService.get_current_grade(employee)
        
        if not grade_history:
            return 0
        
        today = date.today()
        start_date = grade_history.start_date
        
        # حساب الفرق بالأشهر
        delta = relativedelta(today, start_date)
        total_months = delta.years * 12 + delta.months
        
        return total_months
    
    @staticmethod
    def get_full_name(employee, language='ar'):
        """الحصول على الاسم الكامل حسب اللغة"""
        if language == 'ar':
            if employee.first_name_ar and employee.last_name_ar:
                return f"{employee.first_name_ar} {employee.last_name_ar}"
        return f"{employee.first_name} {employee.last_name}"


class PromotionCalculator:
    """
    محرك حساب الترقيات
    مسؤول عن حساب استحقاق الترقيات وتواريخها
    """
    
    # القيم الافتراضية - يمكن جعلها قابلة للتكوين من قاعدة البيانات
    DEFAULT_PROMOTION_MONTHS = {
        1: 18,  # من درجة 1 إلى 2: 18 شهر
        2: 18,
        3: 18,
        4: 24,  # من درجة 4 إلى 5: 24 شهر
        5: 24,
        6: 24,
        7: 30,
        8: 30,
        9: 30,
        10: 36,
        11: 36,
        12: 36,
    }
    
    @staticmethod
    def get_required_months(current_grade, custom_rules=None):
        """
        الحصول على عدد الأشهر المطلوبة للترقية
        يمكن تمرير قواعد مخصصة لتجاوز القيم الافتراضية
        """
        if custom_rules and current_grade in custom_rules:
            return custom_rules[current_grade]
        return PromotionCalculator.DEFAULT_PROMOTION_MONTHS.get(current_grade, 24)
    
    @staticmethod
    def calculate_eligibility_date(grade_start_date, current_grade, custom_rules=None):
        """
        حساب تاريخ الاستحقاق للترقية
        """
        required_months = PromotionCalculator.get_required_months(current_grade, custom_rules)
        return grade_start_date + relativedelta(months=required_months)
    
    @staticmethod
    def get_promotion_status(eligibility_date, today=None):
        """
        تحديد حالة الترقية بناءً على تاريخ الاستحقاق
        """
        if not today:
            today = date.today()
        
        if not eligibility_date:
            return 'NOT_ELIGIBLE'
        
        days_until = (eligibility_date - today).days
        
        if days_until <= 0:
            return 'ELIGIBLE'
        elif days_until <= 30:
            return 'NEAR_ELIGIBLE'
        elif days_until <= 90:
            return 'UPCOMING'
        else:
            return 'NOT_ELIGIBLE'
    
    @staticmethod
    @transaction.atomic
    def calculate_employee_promotions(year=None, category=None):
        """
        حساب استحقاقات الترقيات لجميع الموظفين
        يمكن تصفية حسب السنة أو الصنف
        """
        from employees.models import Employee
        from promotions.models import PromotionEligibility
        from grades.models import Category
        
        if not year:
            year = date.today().year
        
        employees = Employee.objects.filter(status='ACTIVE')
        
        if category:
            employees = employees.filter(grade_history__category=category, grade_history__is_current=True)
        
        results = {
            'total': 0,
            'eligible': 0,
            'near_eligible': 0,
            'not_eligible': 0,
            'processed': 0,
        }
        
        for employee in employees:
            grade_history = EmployeeService.get_current_grade(employee)
            
            if not grade_history:
                continue
            
            current_grade = grade_history.grade_number
            next_grade = current_grade + 1
            cat = grade_history.category
            
            # التحقق من وجود سجل استحقاق سابق
            eligibility, created = PromotionEligibility.objects.get_or_create(
                employee=employee,
                year=year,
                category=cat,
                defaults={
                    'current_grade': current_grade,
                    'next_grade': next_grade,
                }
            )
            
            if not created:
                # تحديث السجل الموجود
                eligibility.current_grade = current_grade
                eligibility.next_grade = next_grade
            
            # حساب الأقدمية
            seniority_months = PromotionCalculator.calculate_seniority_months_in_grade(
                grade_history.start_date
            )
            eligibility.seniority_months = seniority_months
            
            # الحصول على الأشهر المطلوبة
            required_months = PromotionCalculator.get_required_months(current_grade)
            eligibility.required_months = required_months
            
            # حساب تاريخ الاستحقاق
            eligibility_date = PromotionCalculator.calculate_eligibility_date(
                grade_history.start_date,
                current_grade
            )
            eligibility.eligibility_date = eligibility_date
            
            # تحديد الحالة
            eligibility.status = PromotionCalculator.get_promotion_status(eligibility_date)
            
            # تحديث العدادات
            results['total'] += 1
            if eligibility.status == 'ELIGIBLE':
                results['eligible'] += 1
            elif eligibility.status == 'NEAR_ELIGIBLE':
                results['near_eligible'] += 1
            else:
                results['not_eligible'] += 1
            
            if eligibility.is_processed:
                results['processed'] += 1
            
            eligibility.save()
        
        return results
    
    @staticmethod
    def calculate_seniority_months_in_grade(start_date):
        """حساب مدة الأقدمية بالأشهر منذ تاريخ البداية"""
        today = date.today()
        delta = relativedelta(today, start_date)
        return delta.years * 12 + delta.months
    
    @staticmethod
    def get_employees_by_promotion_status(status, year=None):
        """
        الحصول على الموظفين حسب حالة الترقية
        """
        from promotions.models import PromotionEligibility
        
        if not year:
            year = date.today().year
        
        eligibilities = PromotionEligibility.objects.filter(
            year=year,
            status=status
        ).select_related('employee', 'category')
        
        return eligibilities
