"""
ViewSets for Employee API
"""
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.pagination import PageNumberPagination
from django.utils.translation import gettext_lazy as _
from django.db.models import Q

from .models import Employee, EmployeeRankHistory, EmployeeGradeHistory
from .serializers import (
    EmployeeSerializer, 
    EmployeeBriefSerializer, 
    EmployeeDetailSerializer,
    EmployeeRankHistorySerializer,
    EmployeeGradeHistorySerializer
)


class StandardResultsSetPagination(PageNumberPagination):
    """Standard pagination for API responses"""
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100


class EmployeeViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing employees
    
    API Endpoints:
    - GET /api/v1/employees/ - List all employees
    - POST /api/v1/employees/ - Create employee
    - GET /api/v1/employees/{id}/ - Retrieve employee
    - PUT /api/v1/employees/{id}/ - Update employee
    - DELETE /api/v1/employees/{id}/ - Delete employee (soft delete)
    - GET /api/v1/employees/{id}/career/ - Get employee career timeline
    - GET /api/v1/employees/{id}/ranks/ - Get employee rank history
    - GET /api/v1/employees/{id}/grades/ - Get employee grade history
    - GET /api/v1/employees/search/ - Search employees
    """
    queryset = Employee.objects.select_related().prefetch_related(
        'rank_history',
        'grade_history'
    ).filter(deleted_at__isnull=True)
    serializer_class = EmployeeSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = {
        'status': ['exact'],
        'gender': ['exact'],
        'family_status': ['exact'],
        'blood_type': ['exact'],
        'recruitment_date': ['exact', 'gte', 'lte'],
        'installation_date': ['exact', 'gte', 'lte'],
    }
    search_fields = [
        'nin',
        'matricule',
        'internal_id',
        'last_name',
        'first_name',
        'last_name_ar',
        'first_name_ar',
        'email',
        'phone',
        'social_security_number',
    ]
    ordering_fields = [
        'last_name',
        'first_name',
        'last_name_ar',
        'first_name_ar',
        'recruitment_date',
        'created_at',
        'updated_at',
    ]
    ordering = ['last_name']
    pagination_class = StandardResultsSetPagination
    
    def get_serializer_class(self):
        """Return appropriate serializer based on action"""
        if self.action == 'list':
            return EmployeeBriefSerializer
        elif self.action in ['retrieve', 'career_timeline']:
            return EmployeeDetailSerializer
        return EmployeeSerializer
    
    def get_queryset(self):
        """Filter queryset based on user permissions"""
        queryset = super().get_queryset()
        
        # TODO: Implement row-level permissions
        # For now, authenticated users can see all employees
        # In production, filter based on user's organization/department
        
        return queryset
    
    def perform_create(self, serializer):
        """Set created_by when creating employee"""
        serializer.save(created_by=self.request.user)
    
    def perform_update(self, serializer):
        """Set updated_by when updating employee"""
        serializer.save(updated_by=self.request.user)
    
    @action(detail=True, methods=['get'])
    def career_timeline(self, request, pk=None):
        """Get employee career timeline with all events"""
        employee = self.get_object()
        
        timeline_events = []
        
        # Add recruitment event
        timeline_events.append({
            'date': employee.recruitment_date,
            'event_type': 'recruitment',
            'description': _('Recruitment'),
            'details': {
                'matricule': employee.matricule,
            }
        })
        
        # Add installation event
        if employee.installation_date:
            timeline_events.append({
                'date': employee.installation_date,
                'event_type': 'installation',
                'description': _('Installation'),
                'details': {}
            })
        
        # Add rank history events
        for rank_hist in employee.rank_history.all():
            timeline_events.append({
                'date': rank_hist.start_date,
                'event_type': 'rank_change',
                'description': _('Rank Change'),
                'details': {
                    'rank': str(rank_hist.rank),
                    'decision_number': rank_hist.decision_number,
                }
            })
        
        # Add grade history events
        for grade_hist in employee.grade_history.all():
            timeline_events.append({
                'date': grade_hist.start_date,
                'event_type': 'grade_change',
                'description': _('Grade Change'),
                'details': {
                    'grade': grade_hist.grade_number,
                    'category': str(grade_hist.category),
                    'index_value': str(grade_hist.index_value),
                }
            })
        
        # Sort by date
        timeline_events.sort(key=lambda x: x['date'] or date.min)
        
        return Response({
            'employee_id': employee.id,
            'matricule': employee.matricule,
            'full_name': employee.full_name,
            'timeline': timeline_events
        })
    
    @action(detail=True, methods=['get'])
    def ranks(self, request, pk=None):
        """Get employee rank history"""
        employee = self.get_object()
        rank_history = employee.rank_history.all()
        serializer = EmployeeRankHistorySerializer(rank_history, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def grades(self, request, pk=None):
        """Get employee grade history"""
        employee = self.get_object()
        grade_history = employee.grade_history.all()
        serializer = EmployeeGradeHistorySerializer(grade_history, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def search(self, request):
        """Advanced search for employees"""
        query = request.query_params.get('q', '')
        
        if not query:
            return Response([])
        
        # Search across multiple fields
        queryset = self.get_queryset().filter(
            Q(nin__icontains=query) |
            Q(matricule__icontains=query) |
            Q(last_name__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name_ar__icontains=query) |
            Q(first_name_ar__icontains=query) |
            Q(email__icontains=query) |
            Q(phone__icontains=query)
        )[:50]  # Limit results
        
        serializer = EmployeeBriefSerializer(queryset, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Get employee statistics"""
        from django.db.models import Count
        
        stats = {
            'total': self.get_queryset().count(),
            'by_status': dict(
                self.get_queryset()
                .values('status')
                .annotate(count=Count('id'))
                .values_list('status', 'count')
            ),
            'by_gender': dict(
                self.get_queryset()
                .values('gender')
                .annotate(count=Count('id'))
                .values_list('gender', 'count')
            ),
        }
        
        return Response(stats)


class EmployeeRankHistoryViewSet(viewsets.ModelViewSet):
    """ViewSet for managing employee rank history"""
    queryset = EmployeeRankHistory.objects.select_related('employee', 'rank').all()
    serializer_class = EmployeeRankHistorySerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = {
        'employee': ['exact'],
        'rank': ['exact'],
        'is_current': ['exact'],
        'start_date': ['exact', 'gte', 'lte'],
    }
    ordering_fields = ['start_date', 'created_at']
    ordering = ['-start_date']
    pagination_class = StandardResultsSetPagination
    
    def perform_create(self, serializer):
        serializer.save()
    
    def perform_update(self, serializer):
        serializer.save()


class EmployeeGradeHistoryViewSet(viewsets.ModelViewSet):
    """ViewSet for managing employee grade history"""
    queryset = EmployeeGradeHistory.objects.select_related('employee', 'category').all()
    serializer_class = EmployeeGradeHistorySerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = {
        'employee': ['exact'],
        'category': ['exact'],
        'is_current': ['exact'],
        'start_date': ['exact', 'gte', 'lte'],
    }
    ordering_fields = ['start_date', 'created_at']
    ordering = ['-start_date']
    pagination_class = StandardResultsSetPagination
    
    def perform_create(self, serializer):
        serializer.save()
    
    def perform_update(self, serializer):
        serializer.save()
