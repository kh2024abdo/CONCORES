from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EmployeeViewSet, EmployeeRankHistoryViewSet, EmployeeGradeHistoryViewSet

router = DefaultRouter()
router.register(r'', EmployeeViewSet, basename='employee')
router.register(r'rank-history', EmployeeRankHistoryViewSet, basename='employee-rank-history')
router.register(r'grade-history', EmployeeGradeHistoryViewSet, basename='employee-grade-history')

urlpatterns = [
    path('', include(router.urls)),
]
