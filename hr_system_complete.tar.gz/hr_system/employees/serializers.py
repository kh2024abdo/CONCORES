"""
Serializers for Employee API
"""
from rest_framework import serializers
from django.utils.translation import gettext_lazy as _
from .models import Employee, EmployeeRankHistory, EmployeeGradeHistory
from organization.models import Structure
from grades.models import Rank, Category


class EmployeeSerializer(serializers.ModelSerializer):
    """Serializer for Employee model"""
    full_name = serializers.ReadOnlyField()
    age = serializers.SerializerMethodField()
    
    class Meta:
        model = Employee
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at', 'created_by', 'updated_by']
    
    def get_age(self, obj):
        if obj.date_of_birth:
            from datetime import date
            today = date.today()
            return today.year - obj.date_of_birth.year - (
                (today.month, today.day) < (obj.date_of_birth.month, obj.date_of_birth.day)
            )
        return None
    
    def validate_nin(self, value):
        """Validate NIN format"""
        if not value:
            raise serializers.ValidationError(_("NIN is required"))
        return value.upper().strip()
    
    def validate_matricule(self, value):
        """Validate Matricule format"""
        if not value:
            raise serializers.ValidationError(_("Matricule is required"))
        return value.upper().strip()


class EmployeeBriefSerializer(serializers.ModelSerializer):
    """Brief serializer for list views"""
    full_name = serializers.ReadOnlyField()
    current_rank = serializers.SerializerMethodField()
    current_grade = serializers.SerializerMethodField()
    structure = serializers.SerializerMethodField()
    
    class Meta:
        model = Employee
        fields = [
            'id', 'matricule', 'nin', 'full_name', 'email', 
            'current_rank', 'current_grade', 'structure', 'status'
        ]
    
    def get_current_rank(self, obj):
        current_rank = obj.rank_history.filter(is_current=True).first()
        if current_rank:
            return str(current_rank.rank)
        return None
    
    def get_current_grade(self, obj):
        current_grade = obj.grade_history.filter(is_current=True).first()
        if current_grade:
            return f"Grade {current_grade.grade_number}"
        return None
    
    def get_structure(self, obj):
        # Will be implemented with assignments
        return None


class EmployeeRankHistorySerializer(serializers.ModelSerializer):
    """Serializer for Employee Rank History"""
    rank_name = serializers.CharField(source='rank.name', read_only=True)
    rank_name_ar = serializers.CharField(source='rank.name_ar', read_only=True)
    
    class Meta:
        model = EmployeeRankHistory
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']
    
    def validate(self, data):
        """Validate dates"""
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        
        if start_date and end_date and end_date < start_date:
            raise serializers.ValidationError({
                'end_date': _("End date must be after start date")
            })
        
        return data


class EmployeeGradeHistorySerializer(serializers.ModelSerializer):
    """Serializer for Employee Grade History"""
    category_name = serializers.CharField(source='category.name', read_only=True)
    next_promotion_date = serializers.ReadOnlyField()
    
    class Meta:
        model = EmployeeGradeHistory
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at', 'next_promotion_date']
    
    def validate(self, data):
        """Validate dates and grade progression"""
        start_date = data.get('start_date')
        effect_date = data.get('effect_date')
        
        if start_date and effect_date and effect_date < start_date:
            raise serializers.ValidationError({
                'effect_date': _("Effective date must be after start date")
            })
        
        return data


class EmployeeDetailSerializer(serializers.ModelSerializer):
    """Detailed serializer for employee detail view with all related data"""
    full_name = serializers.ReadOnlyField()
    full_name_fr = serializers.ReadOnlyField()
    age = serializers.SerializerMethodField()
    current_rank = serializers.SerializerMethodField()
    current_grade = serializers.SerializerMethodField()
    rank_history = EmployeeRankHistorySerializer(many=True, read_only=True)
    grade_history = EmployeeGradeHistorySerializer(many=True, read_only=True)
    
    class Meta:
        model = Employee
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at', 'created_by', 'updated_by']
    
    def get_age(self, obj):
        if obj.date_of_birth:
            from datetime import date
            today = date.today()
            return today.year - obj.date_of_birth.year - (
                (today.month, today.day) < (obj.date_of_birth.month, obj.date_of_birth.day)
            )
        return None
    
    def get_current_rank(self, obj):
        current_rank = obj.rank_history.filter(is_current=True).first()
        if current_rank:
            return EmployeeRankHistorySerializer(current_rank).data
        return None
    
    def get_current_grade(self, obj):
        current_grade = obj.grade_history.filter(is_current=True).first()
        if current_grade:
            return EmployeeGradeHistorySerializer(current_grade).data
        return None
