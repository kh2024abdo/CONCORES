from django.core.management.base import BaseCommand
from django.utils.translation import gettext_lazy as _
from organization.models import Institution, Structure
from grades.models import RankBody, Category, Rank, GradeScaleVersion, GradeScaleItem
from employees.models import Employee
from datetime import date, timedelta


class Command(BaseCommand):
    help = _('Create demo data for development and testing')

    def handle(self, *args, **options):
        self.stdout.write(_('Creating demo data...'))

        # Create institution
        institution, _ = Institution.objects.get_or_create(
            code='UNIV001',
            defaults={
                'name_ar': 'جامعة الجزائر',
                'name_fr': 'University of Algiers',
                'name_en': 'University of Algiers',
            }
        )
        self.stdout.write(f'Created institution: {institution}')

        # Create structures
        structures_data = [
            {'code': 'DRH', 'name_ar': 'مديرية الموارد البشرية', 'name_fr': 'Direction des Ressources Humaines', 'type': 'DIRECTORATE'},
            {'code': 'DF', 'name_ar': 'مديرية المالية', 'name_fr': 'Direction des Finances', 'type': 'DIRECTORATE'},
            {'code': 'DP', 'name_ar': 'مديرية التخطيط', 'name_fr': 'Direction de la Planification', 'type': 'DIRECTORATE'},
            {'code': 'FAC1', 'name_ar': 'كلية العلوم', 'name_fr': 'Faculté des Sciences', 'type': 'FACULTY'},
            {'code': 'FAC2', 'name_ar': 'كلية الآداب', 'name_fr': 'Faculté des Lettres', 'type': 'FACULTY'},
        ]

        for struct_data in structures_data:
            structure, _ = Structure.objects.get_or_create(
                code=struct_data['code'],
                defaults={
                    'name_ar': struct_data['name_ar'],
                    'name_fr': struct_data['name_fr'],
                    'institution': institution,
                    'structure_type': struct_data['type'],
                }
            )
            self.stdout.write(f'Created structure: {structure}')

        # Create rank bodies
        bodies_data = [
            {'code': 'PROF', 'name_ar': 'سلك الأساتذة', 'name_fr': 'Corps des Professeurs'},
            {'code': 'ADMIN', 'name_ar': 'سلك الإداريين', 'name_fr': 'Corps des Administratifs'},
            {'code': 'TECH', 'name_ar': 'سلك التقنيين', 'name_fr': 'Corps des Techniciens'},
        ]

        for body_data in bodies_data:
            body, _ = RankBody.objects.get_or_create(
                code=body_data['code'],
                defaults={
                    'name_ar': body_data['name_ar'],
                    'name_fr': body_data['name_fr'],
                }
            )
            self.stdout.write(f'Created rank body: {body}')

        # Create categories
        categories_data = [
            {'code': 'C10', 'order': 10, 'name_ar': 'صنف 10', 'name_fr': 'Catégorie 10'},
            {'code': 'C12', 'order': 12, 'name_ar': 'صنف 12', 'name_fr': 'Catégorie 12'},
            {'code': 'C14', 'order': 14, 'name_ar': 'صنف 14', 'name_fr': 'Catégorie 14'},
            {'code': 'C16', 'order': 16, 'name_ar': 'صنف 16', 'name_fr': 'Catégorie 16'},
        ]

        categories = {}
        for cat_data in categories_data:
            category, _ = Category.objects.get_or_create(
                code=cat_data['code'],
                defaults={
                    'order': cat_data['order'],
                    'name_ar': cat_data['name_ar'],
                    'name_fr': cat_data['name_fr'],
                }
            )
            categories[cat_data['code']] = category
            self.stdout.write(f'Created category: {category}')

        # Create ranks
        ranks_data = [
            {'body': 'ADMIN', 'category': 'C10', 'code': 'SEC', 'name_ar': 'كاتب إداري', 'name_fr': 'Secrétaire Administratif'},
            {'body': 'ADMIN', 'category': 'C12', 'code': 'ADMIN_ASSIST', 'name_ar': 'مساعد إداري', 'name_fr': 'Assistant Administratif'},
            {'body': 'ADMIN', 'category': 'C14', 'code': 'ADMIN_MANAGER', 'name_ar': 'متصرف إداري', 'name_fr': 'Gestionnaire Administratif'},
            {'body': 'TECH', 'category': 'C10', 'code': 'TECH', 'name_ar': 'تقني', 'name_fr': 'Technicien'},
            {'body': 'TECH', 'category': 'C12', 'code': 'SR_TECH', 'name_ar': 'تقني سامٍ', 'name_fr': 'Technicien Supérieur'},
        ]

        for rank_data in ranks_data:
            body = RankBody.objects.get(code=rank_data['body'])
            category = categories[rank_data['category']]
            rank, _ = Rank.objects.get_or_create(
                code=rank_data['code'],
                defaults={
                    'body': body,
                    'category': category,
                    'name_ar': rank_data['name_ar'],
                    'name_fr': rank_data['name_fr'],
                }
            )
            self.stdout.write(f'Created rank: {rank}')

        # Create grade scale version
        scale_version, _ = GradeScaleVersion.objects.get_or_create(
            name='شبكة 2024',
            defaults={
                'effective_from': date(2024, 1, 1),
                'is_current': True,
            }
        )

        # Create grade scale items
        index_values = {
            ('C10', 1): 300, ('C10', 2): 320, ('C10', 3): 340,
            ('C12', 1): 380, ('C12', 2): 410, ('C12', 3): 440,
            ('C14', 1): 500, ('C14', 2): 540, ('C14', 3): 580,
        }

        for (cat_code, grade), index in index_values.items():
            GradeScaleItem.objects.get_or_create(
                version=scale_version,
                category=categories[cat_code],
                grade_number=grade,
                defaults={'index_value': index}
            )

        self.stdout.write('Created grade scale items')

        # Create demo employees
        first_names = ['أحمد', 'محمد', 'فاطمة', 'عمر', 'خديجة']
        last_names = ['بن علي', 'بومدين', 'زياني', 'حمادي', 'مسعودي']

        for i in range(5):
            nin = f'{100000000 + i:09d}'
            matricule = f'MAT{2020000 + i}'
            
            employee, created = Employee.objects.get_or_create(
                nin=nin,
                defaults={
                    'matricule': matricule,
                    'first_name': first_names[i % len(first_names)],
                    'last_name': last_names[i % len(last_names)],
                    'first_name_ar': first_names[i % len(first_names)],
                    'last_name_ar': last_names[i % len(last_names)],
                    'gender': 'M' if i % 2 == 0 else 'F',
                    'date_of_birth': date(1980 + i, 1, 1),
                    'place_of_birth': 'الجزائر',
                    'recruitment_date': date(2020, 1, 1) + timedelta(days=i*30),
                    'status': 'ACTIVE',
                }
            )
            
            if created:
                from employees.models import EmployeeRankHistory, EmployeeGradeHistory
                
                rank = Rank.objects.first()
                EmployeeRankHistory.objects.create(
                    employee=employee,
                    rank=rank,
                    start_date=date(2020, 1, 1),
                    is_current=True,
                )
                
                category = list(categories.values())[0]
                EmployeeGradeHistory.objects.create(
                    employee=employee,
                    category=category,
                    grade_number=1,
                    index_value=300,
                    start_date=date(2020, 1, 1),
                    is_current=True,
                )
                
                self.stdout.write(f'Created employee: {employee}')

        self.stdout.write(self.style.SUCCESS(_('Demo data created successfully!')))
