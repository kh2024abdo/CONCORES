from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, ReferenceModel


class Institution(ReferenceModel):
    """
    Top-level institution (e.g., Ministry, University).
    """
    code = models.CharField(
        _('code'),
        max_length=50,
        unique=True
    )
    logo = models.ImageField(
        _('logo'),
        upload_to='institutions/logos/',
        blank=True,
        null=True
    )
    address_ar = models.TextField(
        _('address (Arabic)'),
        blank=True
    )
    address_fr = models.TextField(
        _('address (French)'),
        blank=True
    )
    phone = models.CharField(
        _('phone'),
        max_length=20,
        blank=True
    )
    email = models.EmailField(
        _('email'),
        blank=True
    )
    website = models.URLField(
        _('website'),
        blank=True
    )
    
    class Meta:
        db_table = 'organization_institution'
        verbose_name = _('institution')
        verbose_name_plural = _('institutions')
        ordering = ['order', 'name_ar']
    
    def __str__(self):
        return self.name_ar or self.name_fr or self.name_en or self.code


class StructureType(models.TextChoices):
    """Types of organizational structures"""
    DIRECTORATE = 'DIRECTORATE', _('Directorate')
    FACULTY = 'FACULTY', _('Faculty')
    INSTITUTE = 'INSTITUTE', _('Institute')
    DEPARTMENT = 'DEPARTMENT', _('Department')
    SERVICE = 'SERVICE', _('Service')
    UNIT = 'UNIT', _('Unit')
    DIVISION = 'DIVISION', _('Division')
    SECTION = 'SECTION', _('Section')
    OTHER = 'OTHER', _('Other')


class Structure(TimeStampedModel):
    """
    Organizational structure (Directorate, Faculty, Department, Service, etc.).
    Supports hierarchical structure with parent-child relationships.
    """
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='structures',
        verbose_name=_('institution')
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='children',
        verbose_name=_('parent structure'),
        help_text=_('Parent structure in the hierarchy')
    )
    type = models.CharField(
        _('type'),
        max_length=20,
        choices=StructureType.choices,
        default=StructureType.DEPARTMENT
    )
    code = models.CharField(
        _('code'),
        max_length=50,
        help_text=_('Unique code for this structure')
    )
    name_ar = models.CharField(
        _('name (Arabic)'),
        max_length=200
    )
    name_fr = models.CharField(
        _('name (French)'),
        max_length=200
    )
    name_en = models.CharField(
        _('name (English)'),
        max_length=200,
        blank=True
    )
    description_ar = models.TextField(
        _('description (Arabic)'),
        blank=True
    )
    description_fr = models.TextField(
        _('description (French)'),
        blank=True
    )
    is_active = models.BooleanField(
        _('is active'),
        default=True
    )
    order = models.PositiveIntegerField(
        _('order'),
        default=0
    )
    
    class Meta:
        db_table = 'organization_structure'
        verbose_name = _('structure')
        verbose_name_plural = _('structures')
        ordering = ['institution', 'parent', 'order', 'name_ar']
        unique_together = ['institution', 'code']
        indexes = [
            models.Index(fields=['parent', 'is_active']),
            models.Index(fields=['type', 'is_active']),
        ]
    
    def __str__(self):
        return f'{self.get_type_display()} - {self.name_ar}'
    
    @property
    def full_name(self):
        """Get full hierarchical name"""
        names = []
        current = self
        while current:
            from django.utils.translation import get_language
            lang = get_language()
            if lang == 'ar':
                names.append(current.name_ar)
            elif lang == 'fr':
                names.append(current.name_fr)
            else:
                names.append(current.name_en or current.name_ar)
            current = current.parent
        return ' > '.join(reversed(names))
    
    @property
    def display_name(self):
        """Get display name based on current language"""
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar':
            return self.name_ar
        elif lang == 'fr':
            return self.name_fr
        return self.name_en or self.name_ar
    
    def get_descendants(self):
        """Get all descendant structures"""
        descendants = []
        for child in self.children.all():
            descendants.append(child)
            descendants.extend(child.get_descendants())
        return descendants
    
    def get_ancestors(self):
        """Get all ancestor structures"""
        ancestors = []
        current = self.parent
        while current:
            ancestors.append(current)
            current = current.parent
        return ancestors


class Position(TimeStampedModel):
    """
    Job position within a structure.
    """
    structure = models.ForeignKey(
        Structure,
        on_delete=models.CASCADE,
        related_name='positions',
        verbose_name=_('structure')
    )
    code = models.CharField(
        _('code'),
        max_length=50,
        help_text=_('Unique code for this position')
    )
    name_ar = models.CharField(
        _('name (Arabic)'),
        max_length=200
    )
    name_fr = models.CharField(
        _('name (French)'),
        max_length=200
    )
    name_en = models.CharField(
        _('name (English)'),
        max_length=200,
        blank=True
    )
    description_ar = models.TextField(
        _('description (Arabic)'),
        blank=True
    )
    description_fr = models.TextField(
        _('description (French)'),
        blank=True
    )
    level = models.PositiveIntegerField(
        _('level'),
        help_text=_('Position level in hierarchy'),
        default=1
    )
    is_managerial = models.BooleanField(
        _('is managerial'),
        default=False,
        help_text=_('Whether this is a managerial position')
    )
    is_active = models.BooleanField(
        _('is active'),
        default=True
    )
    order = models.PositiveIntegerField(
        _('order'),
        default=0
    )
    
    class Meta:
        db_table = 'organization_position'
        verbose_name = _('position')
        verbose_name_plural = _('positions')
        ordering = ['structure', 'level', 'order', 'name_ar']
        unique_together = ['structure', 'code']
        indexes = [
            models.Index(fields=['is_managerial', 'is_active']),
            models.Index(fields=['level', 'is_active']),
        ]
    
    def __str__(self):
        return f'{self.structure.display_name} - {self.name_ar}'
    
    @property
    def display_name(self):
        """Get display name based on current language"""
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar':
            return self.name_ar
        elif lang == 'fr':
            return self.name_fr
        return self.name_en or self.name_ar
