from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, SoftDeleteModel
from employees.models import Employee
from organization.models import Structure


class SeniorPosition(SoftDeleteModel, TimeStampedModel):
    """
    المناصب العليا - يسجل كل منصب عالي شغله الموظف
    أمثلة: مدير، رئيس قسم، رئيس مصلحة...
    """
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='senior_positions')
    structure = models.ForeignKey(Structure, on_delete=models.CASCADE, related_name='senior_positions')
    position_name = models.CharField(_("Position Name"), max_length=200)
    position_name_ar = models.CharField(_("Position Name (AR)"), max_length=200, blank=True)
    position_name_fr = models.CharField(_("Position Name (FR)"), max_length=200, blank=True)
    start_date = models.DateField(_("Start Date"))
    end_date = models.DateField(_("End Date"), null=True, blank=True)
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/senior_positions/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    is_current = models.BooleanField(_("Is Current"), default=False)
    
    class Meta:
        verbose_name = _("Senior Position")
        verbose_name_plural = _("Senior Positions")
        ordering = ['-start_date']
        constraints = [
            models.CheckConstraint(
                condition=models.Q(end_date__gte=models.F('start_date')) | models.Q(end_date__isnull=True),
                name='senior_position_end_date_after_start'
            )
        ]
        indexes = [
            models.Index(fields=['employee', 'is_current']),
            models.Index(fields=['structure', 'is_current']),
        ]
    
    def __str__(self):
        name = self.position_name_ar or self.position_name_fr or self.position_name
        return f"{self.employee} - {name} ({self.start_date})"
    
    def save(self, *args, **kwargs):
        if self.is_current:
            # جعل السجلات الأخرى غير حالية
            SeniorPosition.objects.filter(employee=self.employee, is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)
    
    @property
    def position_name_display(self):
        """Return position name in Arabic if available, otherwise French"""
        return self.position_name_ar or self.position_name_fr or self.position_name
