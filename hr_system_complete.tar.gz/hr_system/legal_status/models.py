from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, SoftDeleteModel, ReferenceModel
from employees.models import Employee


class LegalStatusType(ReferenceModel):
    """
    أنواع الوضعيات القانونية - قابلة للإدارة من لوحة التحكم
    أمثلة: في الخدمة، عطلة مرضية، انتداب، إلحاق، استيداع، إحالة...
    """
    code = models.CharField(_("Code"), max_length=20, unique=True)
    affects_seniority = models.BooleanField(_("Affects Seniority"), default=False, help_text=_("Does this status pause seniority calculation?"))
    is_active = models.BooleanField(_("Active"), default=True)
    
    class Meta:
        verbose_name = _("Legal Status Type")
        verbose_name_plural = _("Legal Status Types")
        ordering = ['name_ar']
    
    def __str__(self):
        return self.name_ar or self.name_fr or self.code


class LegalStatus(SoftDeleteModel, TimeStampedModel):
    """
    الوضعية القانونية للموظف
    يسجل كل تغير في الوضعية القانونية عبر المسار المهني
    """
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='legal_statuses')
    status_type = models.ForeignKey(LegalStatusType, on_delete=models.CASCADE, related_name='statuses', verbose_name=_("Status Type"))
    start_date = models.DateField(_("Start Date"))
    end_date = models.DateField(_("End Date"), null=True, blank=True, help_text=_("Leave empty for ongoing status"))
    legal_reference = models.CharField(_("Legal Reference"), max_length=200, blank=True, help_text=_("Legal text reference"))
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/legal_status/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    is_current = models.BooleanField(_("Is Current"), default=False)
    
    class Meta:
        verbose_name = _("Legal Status")
        verbose_name_plural = _("Legal Statuses")
        ordering = ['-start_date']
        constraints = [
            models.CheckConstraint(
                condition=models.Q(end_date__gte=models.F('start_date')) | models.Q(end_date__isnull=True),
                name='legal_status_end_date_after_start'
            )
        ]
        indexes = [
            models.Index(fields=['employee', 'is_current']),
            models.Index(fields=['status_type', 'is_current']),
        ]
    
    def __str__(self):
        return f"{self.employee} - {self.status_type} ({self.start_date})"
    
    def save(self, *args, **kwargs):
        if self.is_current:
            # جعل السجلات الأخرى غير حالية
            LegalStatus.objects.filter(employee=self.employee, is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)
    
    @property
    def is_ongoing(self):
        """هل الوضعية مستمرة بدون تاريخ نهاية؟"""
        return self.is_current and self.end_date is None
