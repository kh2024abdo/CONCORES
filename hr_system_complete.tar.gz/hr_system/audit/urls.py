from django.urls import path, include

# Placeholder URLs - to be implemented
urlpatterns = [
    # API endpoints will be added here
]
