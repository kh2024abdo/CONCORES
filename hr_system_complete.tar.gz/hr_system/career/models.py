from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, SoftDeleteModel
from employees.models import Employee
from organization.models import Structure


class Assignment(SoftDeleteModel, TimeStampedModel):
    """
    التوجيه/الإلحاق - ي记录了 جميع أماكن عمل الموظف
    يحفظ التاريخ الكامل للتوجيهات
    """
    
    ASSIGNMENT_TYPE_CHOICES = [
        ('ASSIGNMENT', _("Assignment")),
        ('TRANSFER', _("Transfer")),
        ('SECONDMENT', _("Secondment")),
        ('DETACHMENT', _("Detachment")),
        ('REINTEGRATION', _("Reintegration")),
    ]
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='assignments')
    structure = models.ForeignKey(Structure, on_delete=models.CASCADE, related_name='employee_assignments')
    position = models.ForeignKey('organization.Position', on_delete=models.SET_NULL, null=True, blank=True, related_name='employee_assignments')
    assignment_type = models.CharField(_("Assignment Type"), max_length=20, choices=ASSIGNMENT_TYPE_CHOICES)
    start_date = models.DateField(_("Start Date"))
    end_date = models.DateField(_("End Date"), null=True, blank=True)
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/assignments/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    is_current = models.BooleanField(_("Is Current"), default=False)
    
    class Meta:
        verbose_name = _("Assignment")
        verbose_name_plural = _("Assignments")
        ordering = ['-start_date']
        constraints = [
            models.CheckConstraint(
                condition=models.Q(end_date__gte=models.F('start_date')) | models.Q(end_date__isnull=True),
                name='assignment_end_date_after_start'
            )
        ]
        indexes = [
            models.Index(fields=['employee', 'is_current']),
            models.Index(fields=['structure', 'is_current']),
        ]
    
    def __str__(self):
        return f"{self.employee} - {self.structure} ({self.start_date})"
    
    def save(self, *args, **kwargs):
        if self.is_current:
            # جعل السجلات الأخرى غير حالية
            Assignment.objects.filter(employee=self.employee, is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)


class WorkLocation(TimeStampedModel):
    """
    مكان العمل التفصيلي داخل الهيكل
    """
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name='work_locations')
    department = models.CharField(_("Department"), max_length=200, blank=True)
    service = models.CharField(_("Service"), max_length=200, blank=True)
    unit = models.CharField(_("Unit"), max_length=200, blank=True)
    workplace = models.CharField(_("Workplace"), max_length=200, blank=True)
    
    class Meta:
        verbose_name = _("Work Location")
        verbose_name_plural = _("Work Locations")
    
    def __str__(self):
        return f"{self.assignment} - {self.department or self.service or self.unit or self.workplace}"
