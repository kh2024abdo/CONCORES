from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, AuditedModel


class UserManager(BaseUserManager):
    """
    Custom user model manager for email-based authentication.
    """
    
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError(_('Users must have an email address'))
        
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        
        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))
        
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser, TimeStampedModel):
    """
    Custom User model with email-based authentication.
    Supports multilingual names and additional HR-related fields.
    """
    
    # Remove username field, use email instead
    username = None
    email = models.EmailField(
        _('email address'),
        unique=True,
        help_text=_('Email address used for login')
    )
    
    # Multilingual names
    first_name_ar = models.CharField(
        _('first name (Arabic)'),
        max_length=100,
        blank=True
    )
    last_name_ar = models.CharField(
        _('last name (Arabic)'),
        max_length=100,
        blank=True
    )
    first_name_fr = models.CharField(
        _('first name (French)'),
        max_length=100,
        blank=True
    )
    last_name_fr = models.CharField(
        _('last name (French)'),
        max_length=100,
        blank=True
    )
    
    # Additional fields
    phone = models.CharField(
        _('phone'),
        max_length=20,
        blank=True
    )
    avatar = models.ImageField(
        _('avatar'),
        upload_to='avatars/',
        blank=True,
        null=True
    )
    
    # Department assignment (for object-level permissions)
    department = models.ForeignKey(
        'organization.Structure',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='users',
        verbose_name=_('department'),
        help_text=_('Department this user belongs to')
    )
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']
    
    objects = UserManager()
    
    class Meta:
        db_table = 'auth_user'
        verbose_name = _('user')
        verbose_name_plural = _('users')
        ordering = ['-date_joined']
    
    def __str__(self):
        return self.email or f'{self.first_name} {self.last_name}'
    
    @property
    def full_name_ar(self):
        """Get full name in Arabic"""
        return f'{self.first_name_ar} {self.last_name_ar}'.strip() or self.get_full_name()
    
    @property
    def full_name_fr(self):
        """Get full name in French"""
        return f'{self.first_name_fr} {self.last_name_fr}'.strip() or self.get_full_name()
    
    def get_display_name(self):
        """Get display name based on current language"""
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar':
            return self.full_name_ar
        elif lang == 'fr':
            return self.full_name_fr
        return self.get_full_name()


class Role(TimeStampedModel):
    """
    Role model for role-based access control (RBAC).
    Roles group permissions together.
    """
    
    name = models.CharField(
        _('name'),
        max_length=100,
        unique=True
    )
    name_ar = models.CharField(
        _('name (Arabic)'),
        max_length=100,
        blank=True
    )
    name_fr = models.CharField(
        _('name (French)'),
        max_length=100,
        blank=True
    )
    description = models.TextField(
        _('description'),
        blank=True
    )
    is_system = models.BooleanField(
        _('is system role'),
        default=False,
        help_text=_('System roles cannot be deleted')
    )
    is_active = models.BooleanField(
        _('is active'),
        default=True
    )
    
    class Meta:
        db_table = 'accounts_role'
        verbose_name = _('role')
        verbose_name_plural = _('roles')
        ordering = ['name']
    
    def __str__(self):
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar' and self.name_ar:
            return self.name_ar
        elif lang == 'fr' and self.name_fr:
            return self.name_fr
        return self.name


class UserRole(models.Model):
    """
    Many-to-many relationship between users and roles.
    """
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='role_assignments'
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name='user_assignments'
    )
    assigned_at = models.DateTimeField(
        _('assigned at'),
        auto_now_add=True
    )
    assigned_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='role_assignments_made'
    )
    
    class Meta:
        db_table = 'accounts_user_role'
        verbose_name = _('user role')
        verbose_name_plural = _('user roles')
        unique_together = ['user', 'role']
        ordering = ['-assigned_at']
    
    def __str__(self):
        return f'{self.user.email} - {self.role.name}'


class Permission(models.Model):
    """
    Custom permission model for fine-grained access control.
    Extends Django's default permissions with resource-based permissions.
    """
    
    ACTION_CHOICES = [
        ('view', _('View')),
        ('add', _('Add')),
        ('change', _('Change')),
        ('delete', _('Delete')),
        ('export', _('Export')),
        ('print', _('Print')),
        ('approve', _('Approve')),
        ('reject', _('Reject')),
    ]
    
    codename = models.CharField(
        _('codename'),
        max_length=100,
        unique=True
    )
    name = models.CharField(
        _('name'),
        max_length=200
    )
    name_ar = models.CharField(
        _('name (Arabic)'),
        max_length=200,
        blank=True
    )
    name_fr = models.CharField(
        _('name (French)'),
        max_length=200,
        blank=True
    )
    content_type = models.ForeignKey(
        'contenttypes.ContentType',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='custom_permissions'  # Avoid clash with auth.Permission
    )
    resource = models.CharField(
        _('resource'),
        max_length=100,
        help_text=_('Resource name (e.g., employees, promotions)')
    )
    action = models.CharField(
        _('action'),
        max_length=20,
        choices=ACTION_CHOICES
    )
    description = models.TextField(
        _('description'),
        blank=True
    )
    is_active = models.BooleanField(
        _('is active'),
        default=True
    )
    
    class Meta:
        db_table = 'accounts_permission'
        verbose_name = _('permission')
        verbose_name_plural = _('permissions')
        ordering = ['resource', 'action']
        unique_together = ['resource', 'action', 'content_type']
    
    def __str__(self):
        return f'{self.resource} | {self.get_action_display()} - {self.name}'


class RolePermission(models.Model):
    """
    Many-to-many relationship between roles and permissions.
    """
    
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name='permissions'
    )
    permission = models.ForeignKey(
        Permission,
        on_delete=models.CASCADE,
        related_name='roles'
    )
    assigned_at = models.DateTimeField(
        _('assigned at'),
        auto_now_add=True
    )
    
    class Meta:
        db_table = 'accounts_role_permission'
        verbose_name = _('role permission')
        verbose_name_plural = _('role permissions')
        unique_together = ['role', 'permission']
        ordering = ['role', 'permission']
    
    def __str__(self):
        return f'{self.role.name} - {self.permission.name}'
