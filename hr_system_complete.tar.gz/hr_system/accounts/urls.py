from django.urls import path, include
from rest_framework.routers import DefaultRouter

# Placeholder URLs - will be implemented in Phase 2
urlpatterns = [
    # Auth endpoints will be added here
]
