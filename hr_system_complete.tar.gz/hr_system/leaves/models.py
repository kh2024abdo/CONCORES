from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import TimeStampedModel, SoftDeleteModel, ReferenceModel
from employees.models import Employee


class LeaveType(ReferenceModel):
    """
    أنواع الإجازات - قابلة للإدارة من لوحة التحكم
    """
    code = models.CharField(_("Code"), max_length=20, unique=True)
    duration_days = models.PositiveIntegerField(_("Duration (Days)"), null=True, blank=True, help_text=_("Maximum duration per year"))
    is_paid = models.BooleanField(_("Is Paid"), default=True)
    requires_documentation = models.BooleanField(_("Requires Documentation"), default=False)
    is_active = models.BooleanField(_("Active"), default=True)
    
    class Meta:
        verbose_name = _("Leave Type")
        verbose_name_plural = _("Leave Types")
        ordering = ['name_ar']
    
    def __str__(self):
        return self.name_ar or self.name_fr or self.code


class Leave(SoftDeleteModel, TimeStampedModel):
    """
    الإجازات - يسجل كل إجازة أخذها الموظف
    """
    
    STATUS_CHOICES = [
        ('PENDING', _("Pending")),
        ('APPROVED', _("Approved")),
        ('REJECTED', _("Rejected")),
        ('CANCELLED', _("Cancelled")),
        ('TAKEN', _("Taken")),
    ]
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='leaves')
    leave_type = models.ForeignKey(LeaveType, on_delete=models.CASCADE, related_name='leaves', verbose_name=_("Leave Type"))
    start_date = models.DateField(_("Start Date"))
    end_date = models.DateField(_("End Date"))
    days_count = models.PositiveIntegerField(_("Days Count"), help_text=_("Number of calendar days"))
    working_days = models.PositiveIntegerField(_("Working Days"), null=True, blank=True, help_text=_("Number of working days excluding weekends/holidays"))
    year = models.PositiveIntegerField(_("Year"), help_text=_("Leave year"))
    status = models.CharField(_("Status"), max_length=20, choices=STATUS_CHOICES, default='PENDING')
    decision_number = models.CharField(_("Decision Number"), max_length=100, blank=True)
    decision_date = models.DateField(_("Decision Date"), null=True, blank=True)
    document = models.FileField(_("Document"), upload_to='employees/leaves/', blank=True, null=True)
    notes = models.TextField(_("Notes"), blank=True)
    
    class Meta:
        verbose_name = _("Leave")
        verbose_name_plural = _("Leaves")
        ordering = ['-start_date']
        constraints = [
            models.CheckConstraint(
                condition=models.Q(end_date__gte=models.F('start_date')),
                name='leave_end_date_after_start'
            )
        ]
        indexes = [
            models.Index(fields=['employee', 'status']),
            models.Index(fields=['year', 'status']),
        ]
    
    def __str__(self):
        return f"{self.employee} - {self.leave_type} ({self.start_date} to {self.end_date})"
    
    def clean(self):
        from django.core.exceptions import ValidationError
        if self.end_date < self.start_date:
            raise ValidationError({'end_date': _("End date must be after start date")})
    
    def save(self, *args, **kwargs):
        # حساب عدد الأيام تلقائياً إذا لم يتم تحديده
        if not self.days_count and self.start_date and self.end_date:
            self.days_count = (self.end_date - self.start_date).days + 1
        super().save(*args, **kwargs)


class LeaveBalance(TimeStampedModel):
    """
    رصيد الإجازات السنوي
    """
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='leave_balances')
    leave_type = models.ForeignKey(LeaveType, on_delete=models.CASCADE, related_name='balances')
    year = models.PositiveIntegerField(_("Year"))
    balance_days = models.DecimalField(_("Balance (Days)"), max_digits=5, decimal_places=1, default=0)
    used_days = models.DecimalField(_("Used Days"), max_digits=5, decimal_places=1, default=0)
    remaining_days = models.DecimalField(_("Remaining Days"), max_digits=5, decimal_places=1, default=0)
    
    class Meta:
        verbose_name = _("Leave Balance")
        verbose_name_plural = _("Leave Balances")
        unique_together = ['employee', 'leave_type', 'year']
        ordering = ['-year', 'leave_type']
    
    def __str__(self):
        return f"{self.employee} - {self.leave_type} ({self.year}): {self.remaining_days} days"
