"""
Views للتطبيق Grades/Promotions
"""
from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils.translation import gettext_lazy as _
from django.db.models import Q, Count, Avg
from django.shortcuts import get_object_or_404

from grades.models import (
    RankBody, Category, GradeScaleVersion, GradeScaleItem, Rank,
    PromotionRule, PromotionDecision, PromotionRecord
)
from grades.serializers import (
    RankBodySerializer, CategorySerializer, GradeScaleVersionSerializer,
    GradeScaleItemSerializer, RankSerializer, PromotionRuleSerializer,
    PromotionDecisionSerializer, PromotionDecisionDetailSerializer,
    PromotionRecordSerializer, PromotionEligibilitySerializer,
    PromotionBatchRequestSerializer
)
from grades.services import PromotionCalculator, PromotionService
from employees.models import Employee
from core.permissions import IsHRProfessional, IsAdminOrReadOnly


class RankBodyViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة الأسلاك المهنية
    """
    queryset = RankBody.objects.all()
    serializer_class = RankBodySerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['is_active']
    search_fields = ['name_ar', 'name_fr', 'code']


class CategoryViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة الأصناف
    """
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['is_active']
    search_fields = ['name_ar', 'name_fr', 'code']
    ordering_fields = ['order', 'code']


class GradeScaleVersionViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة إصدارات شبكات الأرقام الاستدلالية
    """
    queryset = GradeScaleVersion.objects.all()
    serializer_class = GradeScaleVersionSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['is_current']
    search_fields = ['name']
    
    @action(detail=False, methods=['get'])
    def current(self, request):
        """الحصول على الإصدار الحالي النشط"""
        current = self.queryset.filter(is_current=True).first()
        if current:
            serializer = self.get_serializer(current)
            return Response(serializer.data)
        return Response({'detail': _('No current scale version found')}, status=404)


class GradeScaleItemViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة عناصر شبكة الأرقام الاستدلالية
    """
    queryset = GradeScaleItem.objects.all()
    serializer_class = GradeScaleItemSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['version', 'category', 'grade_number']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        version_id = self.request.query_params.get('version', None)
        if not version_id:
            # افتراضيًا نرجع الإصدار الحالي
            current_version = GradeScaleVersion.objects.filter(is_current=True).first()
            if current_version:
                queryset = queryset.filter(version=current_version)
        return queryset


class RankViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة الرتب
    """
    queryset = Rank.objects.all()
    serializer_class = RankSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['body', 'category', 'is_active']
    search_fields = ['name_ar', 'name_fr', 'code']
    
    @action(detail=False, methods=['get'])
    def by_category(self, request):
        """الحصول على الرتب مصنفة حسب الصنف"""
        categories = Category.objects.all()
        result = []
        for cat in categories:
            ranks = self.queryset.filter(category=cat, is_active=True)
            if ranks.exists():
                result.append({
                    'category': CategorySerializer(cat).data,
                    'ranks': RankSerializer(ranks, many=True).data
                })
        return Response(result)


class PromotionRuleViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة قواعد الترقية
    """
    queryset = PromotionRule.objects.all()
    serializer_class = PromotionRuleSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ['category', 'is_active', 'from_grade_number', 'to_grade_number']
    
    @action(detail=False, methods=['get'])
    def active(self, request):
        """الحصول على القواعد النشطة فقط"""
        rules = self.queryset.filter(is_active=True)
        serializer = self.get_serializer(rules, many=True)
        return Response(serializer.data)


class PromotionDecisionViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لإدارة قرارات الترقية
    """
    queryset = PromotionDecision.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    filterset_fields = ['status', 'decision_date']
    search_fields = ['reference_number', 'description']
    ordering_fields = ['decision_date', 'created_at']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PromotionDecisionDetailSerializer
        return PromotionDecisionSerializer
    
    def get_queryset(self):
        queryset = super().get_queryset()
        # تصفية حسب صلاحيات المستخدم (يمكن توسيعها لاحقًا)
        if not self.request.user.is_superuser:
            # الموظفون العاديون يرون فقط القرارات المنشورة
            queryset = queryset.filter(status__in=['approved', 'published'])
        return queryset
    
    @action(detail=True, methods=['post'])
    def publish(self, request, pk=None):
        """نشر قرار الترقية"""
        decision = self.get_object()
        if decision.status == 'draft':
            decision.status = 'published'
            decision.save()
            return Response({'status': 'published'})
        return Response(
            {'detail': _('Cannot publish this decision in its current status')},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """الموافقة على قرار الترقية"""
        decision = self.get_object()
        if decision.status == 'pending':
            decision.status = 'approved'
            decision.save()
            return Response({'status': 'approved'})
        return Response(
            {'detail': _('Cannot approve this decision in its current status')},
            status=status.HTTP_400_BAD_REQUEST
        )


class PromotionRecordViewSet(viewsets.ModelViewSet):
    """
    API Endpoint لسجلات الترقية الفردية
    """
    queryset = PromotionRecord.objects.all()
    serializer_class = PromotionRecordSerializer
    permission_classes = [permissions.IsAuthenticated]
    filterset_fields = ['employee', 'decision', 'new_grade']
    ordering_fields = ['created_at', 'seniority_years']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        # الموظفون يمكنهم رؤية سجلاتهم فقط إلا إذا كانوا HR
        if not self.request.user.is_superuser and not hasattr(self.request.user, 'hr_profile'):
            queryset = queryset.filter(employee__user=self.request.user)
        return queryset


class PromotionViewSet(viewsets.ViewSet):
    """
    API Endpoint لعمليات الترقية والحسابات
    عمليات خاصة لا تنتمي لـ CRUD تقليدي
    """
    permission_classes = [permissions.IsAuthenticated]
    
    @action(detail=False, methods=['get'])
    def eligible(self, request):
        """
        الحصول على الموظفين المستحقين للترقية
        """
        filters = {}
        if request.query_params.get('department'):
            filters['department_id'] = request.query_params.get('department')
        if request.query_params.get('rank'):
            filters['rank_id'] = request.query_params.get('rank')
        if request.query_params.get('category'):
            filters['category_id'] = request.query_params.get('category')
        
        eligible_list = PromotionCalculator.get_all_eligible_employees(filters)
        
        # Pagination يدوي
        page = int(request.query_params.get('page', 1))
        page_size = int(request.query_params.get('page_size', 20))
        start = (page - 1) * page_size
        end = start + page_size
        
        paginated = eligible_list[start:end]
        
        results = []
        for item in paginated:
            emp = item['employee']
            elig = item['eligibility']
            results.append({
                'employee_id': emp.id,
                'employee_name': emp.full_name,
                'employee_matricule': emp.matricule,
                'current_grade': elig['current_grade'],
                'next_grade': elig['next_grade'],
                'seniority_years': elig['seniority_years'],
                'seniority_months': elig['seniority_months'],
                'seniority_days': elig['seniority_days'],
                'required_months': elig['required_months'],
                'days_remaining': elig['days_remaining'],
                'status': elig['status'],
                'next_promotion_date': elig['next_promotion_date'],
                'eligible': elig['eligible'],
                'notes': elig['notes']
            })
        
        return Response({
            'count': len(eligible_list),
            'page': page,
            'page_size': page_size,
            'results': results
        })
    
    @action(detail=False, methods=['get'])
    def upcoming(self, request):
        """
        الحصول على الترقيات القادمة خلال X يوم
        """
        days = int(request.query_params.get('days', 90))
        upcoming_list = PromotionCalculator.get_upcoming_promotions(days_ahead=days)
        
        results = []
        for item in upcoming_list[:50]:  # حد أقصى 50 نتيجة
            emp = item['employee']
            elig = item['eligibility']
            results.append({
                'employee_id': emp.id,
                'employee_name': emp.full_name,
                'employee_matricule': emp.matricule,
                'current_grade': elig['current_grade'],
                'next_grade': elig['next_grade'],
                'next_promotion_date': elig['next_promotion_date'],
                'days_remaining': elig['days_remaining'],
                'status': elig['status']
            })
        
        return Response({
            'days_ahead': days,
            'count': len(upcoming_list),
            'results': results
        })
    
    @action(detail=False, methods=['post'])
    def batch_promote(self, request):
        """
        تنفيذ ترقية جماعية
        """
        serializer = PromotionBatchRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # التحقق من الصلاحيات (يجب أن يكون HR Manager أو أعلى)
        if not request.user.is_superuser:
            return Response(
                {'detail': _('You do not have permission to execute batch promotions')},
                status=status.HTTP_403_FORBIDDEN
            )
        
        validated_data = serializer.validated_data
        employee_ids = validated_data['employee_ids']
        
        # الحصول على الموظفين
        employees = Employee.objects.filter(id__in=employee_ids, is_active=True)
        
        if len(employees) != len(employee_ids):
            return Response(
                {'detail': _('Some employees were not found or are inactive')},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # إنشاء قرار الترقية
        decision = PromotionService.create_promotion_decision(
            reference_number=validated_data['reference_number'],
            decision_date=validated_data['decision_date'],
            effective_date=validated_data['effective_date'],
            created_by=request.user,
            description=validated_data.get('description', ''),
            status='draft'
        )
        
        # تحضير قائمة المستحقين
        eligible_list = []
        for emp in employees:
            eligibility = PromotionCalculator.check_eligibility(emp)
            if eligibility['eligible']:
                eligible_list.append({
                    'employee': emp,
                    'eligibility': eligibility
                })
        
        # تنفيذ الترقية الجماعية
        results = PromotionService.execute_batch_promotion(eligible_list, decision)
        
        return Response({
            'decision_id': decision.id,
            'decision_reference': decision.reference_number,
            'success_count': len(results['success']),
            'failed_count': len(results['failed']),
            'skipped_count': len(results['skipped']),
            'details': {
                'success': [
                    {
                        'employee_id': r['employee'].id,
                        'employee_name': r['employee'].full_name,
                        'record_id': r['record'].id
                    } for r in results['success']
                ],
                'failed': [
                    {
                        'employee_id': f['employee'].id,
                        'employee_name': f['employee'].full_name,
                        'error': f['error']
                    } for f in results['failed']
                ]
            }
        }, status=status.HTTP_201_CREATED)
    
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """
        إحصائيات عامة عن الترقيات
        """
        total_decisions = PromotionDecision.objects.count()
        published_decisions = PromotionDecision.objects.filter(status='published').count()
        total_records = PromotionRecord.objects.count()
        
        # متوسط مدة الانتظار للترقية (بالأشهر)
        avg_seniority = PromotionRecord.objects.aggregate(
            avg_months=Avg('seniority_months'),
            avg_years=Avg('seniority_years')
        )
        
        # ترقيات هذا الشهر
        from datetime import datetime
        this_month = PromotionRecord.objects.filter(
            created_at__year=datetime.now().year,
            created_at__month=datetime.now().month
        ).count()
        
        return Response({
            'total_decisions': total_decisions,
            'published_decisions': published_decisions,
            'total_records': total_records,
            'average_seniority_years': avg_seniority['avg_years'] or 0,
            'average_seniority_months': avg_seniority['avg_months'] or 0,
            'promotions_this_month': this_month,
            'eligible_now': PromotionCalculator.get_all_eligible_employees().__len__()
        })
