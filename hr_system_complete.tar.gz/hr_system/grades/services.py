"""
خدمات الترقية - Promotion Services
محرك حساب الاستحقاق للترقية
"""
from datetime import timedelta, date
from django.utils import timezone
from django.db.models import Q, F, ExpressionWrapper, Func, FloatField
from django.db.models.functions import Cast

from grades.models import PromotionRule, PromotionRecord, GradeScaleItem, Category
from employees.models import Employee, EmployeeGradeHistory


class PromotionCalculator:
    """
    محرك حساب استحقاق الترقية.
    يحسب ما إذا كان الموظف مستحقًا للترقية بناءً على:
    - المدة في الدرجة الحالية
    - قواعد الترقية النشطة
    - الوضعيات القانونية التي قد تؤثر على الأقدمية
    """
    
    @staticmethod
    def get_current_grade_history(employee):
        """
        الحصول على آخر سجل درجة للموظف (الدرجة الحالية)
        """
        return EmployeeGradeHistory.objects.filter(employee=employee).order_by('-start_date').first()
        """
        الحصول على آخر سجل درجة للموظف (الدرجة الحالية)
        """
        return EmployeeGradeHistory.objects.filter(employee=employee).order_by('-start_date').first()
    
    @staticmethod
    def calculate_seniority(employee, grade_history=None):
        """
        حساب مدة الأقدمية في الدرجة الحالية.
        ترجع: years, months, days
        """
        if not grade_history:
            grade_history = PromotionCalculator.get_current_grade_history(employee)
        
        if not grade_history:
            return 0, 0, 0
        
        start_date = grade_history.start_date
        end_date = timezone.now().date()
        
        # حساب الفرق الزمني
        delta = end_date - start_date
        total_days = delta.days
        
        years = total_days // 365
        remaining_days = total_days % 365
        months = remaining_days // 30
        days = remaining_days % 30
        
        return years, months, days
    
    @staticmethod
    def get_next_grade(current_grade_number, category):
        """
        تحديد الدرجة التالية بناءً على الدرجة الحالية والصنف.
        """
        next_grade = current_grade_number + 1
        
        # التحقق من وجود قاعدة ترقية نشطة
        rule = PromotionRule.objects.filter(
            from_grade_number=current_grade_number,
            to_grade_number=next_grade,
            category=category,
            is_active=True
        ).first()
        
        if rule:
            return next_grade, rule
        
        # إذا لم توجد قاعدة محددة، نرجع الدرجة التالية افتراضيًا
        return next_grade, None
    
    @staticmethod
    def check_eligibility(employee, ignore_legal_status=False):
        """
        التحقق من أهلية الموظف للترقية.
        ترجع dict يحتوي على:
        - eligible: bool
        - current_grade: int
        - next_grade: int
        - seniority_years: int
        - seniority_months: int
        - seniority_days: int
        - required_months: int
        - days_remaining: int
        - rule: PromotionRule or None
        - status: str (eligible, upcoming, not_eligible, max_grade)
        - next_promotion_date: date or None
        """
        result = {
            'eligible': False,
            'current_grade': None,
            'next_grade': None,
            'seniority_years': 0,
            'seniority_months': 0,
            'seniority_days': 0,
            'required_months': 0,
            'days_remaining': 0,
            'rule': None,
            'status': 'unknown',
            'next_promotion_date': None,
            'notes': []
        }
        
        # الحصول على الدرجة الحالية
        grade_history = PromotionCalculator.get_current_grade_history(employee)
        
        if not grade_history:
            result['status'] = 'no_grade'
            result['notes'].append("لا توجد درجة حالية مسجلة للموظف")
            return result
        
        current_grade = grade_history.grade_number
        category = grade_history.category
        
        result['current_grade'] = current_grade
        
        # التحقق من الوصول لأقصى درجة
        rank_history = employee.rank_history.first()
        if rank_history and current_grade >= rank_history.rank.max_grade:
            result['status'] = 'max_grade'
            result['notes'].append(f"الموظف وصل لأقصى درجة في الرتبة {rank_history.rank}")
            return result
        
        # الحصول على الدرجة التالية والقاعدة
        next_grade, rule = PromotionCalculator.get_next_grade(current_grade, category)
        result['next_grade'] = next_grade
        result['rule'] = rule
        
        # حساب الأقدمية
        years, months, days = PromotionCalculator.calculate_seniority(employee, grade_history)
        result['seniority_years'] = years
        result['seniority_months'] = months
        result['seniority_days'] = days
        
        total_months_in_grade = years * 12 + months
        
        # تحديد المدة المطلوبة
        required_months = 12  # افتراضي سنة واحدة
        if rule:
            required_months = rule.min_duration_months
            # إضافة الأيام ككسر شهر
            if rule.min_duration_days:
                required_months += rule.min_duration_days / 30.0
        
        result['required_months'] = required_months
        
        # حساب التاريخ المتوقع للترقية
        start_date = grade_history.start_date
        required_timedelta = timedelta(days=int(required_months * 30))
        expected_date = start_date + required_timedelta
        result['next_promotion_date'] = expected_date
        
        # التحقق من الأهلية
        if total_months_in_grade >= required_months:
            # التحقق من الوضعيات القانونية التي قد توقف الأقدمية
            if not ignore_legal_status:
                legal_status = None  # TODO: Implement when legal_status app is ready
                if legal_status and getattr(legal_status, 'stops_seniority', False):
                    result['status'] = 'suspended'
                    result['notes'].append(f"الأقدمية موقوفة بسبب الوضعية القانونية: {legal_status.status_type}")
                    return result
            
            result['eligible'] = True
            result['status'] = 'eligible'
        else:
            months_remaining = required_months - total_months_in_grade
            days_remaining = int(months_remaining * 30)
            result['days_remaining'] = days_remaining
            
            if days_remaining <= 30:
                result['status'] = 'upcoming_soon'  # أقل من شهر
            elif days_remaining <= 90:
                result['status'] = 'upcoming_medium'  # أقل من 3 أشهر
            else:
                result['status'] = 'not_eligible'
        
        return result
    
    @staticmethod
    def get_all_eligible_employees(filters=None):
        """
        الحصول على جميع الموظفين المستحقين للترقية.
        filters: dict يحتوي على فلاتر اختيارية (department, rank, category, etc.)
        """
        employees = Employee.objects.filter(status='ACTIVE')
        
        # تطبيق الفلاتر
        if filters:
            if filters.get('department'):
                employees = employees.filter(department=filters['department'])
            if filters.get('rank'):
                employees = employees.filter(rank=filters['rank'])
            if filters.get('category'):
                employees = employees.filter(category=filters['category'])
            if filters.get('min_grade'):
                employees = employees.filter(grade_history__grade_number__gte=filters['min_grade'])
        
        eligible_list = []
        for emp in employees:
            eligibility = PromotionCalculator.check_eligibility(emp)
            if eligibility['eligible']:
                eligible_list.append({
                    'employee': emp,
                    'eligibility': eligibility
                })
        
        return eligible_list
    
    @staticmethod
    def get_upcoming_promotions(days_ahead=90):
        """
        الحصول على الترقيات القادمة خلال عدد معين من الأيام.
        """
        employees = Employee.objects.filter(status='ACTIVE')
        upcoming_list = []
        today = timezone.now().date()
        cutoff_date = today + timedelta(days=days_ahead)
        
        for emp in employees:
            eligibility = PromotionCalculator.check_eligibility(emp)
            
            if eligibility['next_promotion_date']:
                if today <= eligibility['next_promotion_date'] <= cutoff_date:
                    upcoming_list.append({
                        'employee': emp,
                        'eligibility': eligibility
                    })
        
        # ترتيب حسب تاريخ الاستحقاق
        upcoming_list.sort(key=lambda x: x['eligibility']['next_promotion_date'])
        
        return upcoming_list


class PromotionService:
    """
    خدمة تنفيذ الترقيات.
    مسؤولة عن إنشاء سجلات الترقية وتحديث درجات الموظفين.
    """
    
    @staticmethod
    def create_promotion_decision(reference_number, decision_date, effective_date, 
                                   created_by=None, description="", status='draft'):
        """
        إنشاء قرار ترقية جديد.
        """
        from grades.models import PromotionDecision
        
        decision = PromotionDecision.objects.create(
            reference_number=reference_number,
            decision_date=decision_date,
            effective_date=effective_date,
            created_by=created_by,
            description=description,
            status=status
        )
        
        return decision
    
    @staticmethod
    def add_employee_to_promotion(decision, employee, new_grade, new_index, 
                                   notes="", previous_grade=None, previous_index=None):
        """
        إضافة موظف لقرار ترقية.
        ينشئ تلقائيًا PromotionRecord و GradeHistory جديد.
        """
        from grades.models import PromotionRecord
        from employees.models import EmployeeGradeHistory
        from django.db import transaction
        
        with transaction.atomic():
            # الحصول على الدرجة الحالية إذا لم تُحدد
            if not previous_grade:
                current_history = PromotionCalculator.get_current_grade_history(employee)
                if current_history:
                    previous_grade = current_history.grade_number
                    previous_index = current_history.index_value
            
            # إنشاء سجل الترقية
            record = PromotionRecord.objects.create(
                decision=decision,
                employee=employee,
                previous_grade=previous_grade,
                new_grade=new_grade,
                previous_index=previous_index,
                new_index=new_index,
                notes=notes
            )
            
            # حساب مدة الأقدمية
            years, months, days = PromotionCalculator.calculate_seniority(employee)
            record.seniority_years = years
            record.seniority_months = months
            record.seniority_days = days
            record.save()
            
            # إنشاء سجل درجة جديد
            today = timezone.now().date()
            effective_date = max(today, decision.effective_date) if decision.effective_date else today
            
            EmployeeGradeHistory.objects.create(
                employee=employee,
                grade_number=new_grade,
                index_value=new_index,
                start_date=effective_date,
                method='promotion',
                reference_number=decision.reference_number,
                notes=f"ترقية بموجب القرار {decision.reference_number}"
            )
            
            return record
    
    @staticmethod
    def execute_batch_promotion(eligible_list, decision, override_index=False):
        """
        تنفيذ ترقية جماعية للموظفين المستحقين.
        eligible_list: قائمة من dictionaries تحتوي على employee و eligibility
        decision: قرار الترقية
        override_index: هل يجب تجاوز الرقم الاستدلالي المحسوب؟
        """
        from grades.models import GradeScaleItem, Category
        from django.db import transaction
        
        results = {
            'success': [],
            'failed': [],
            'skipped': []
        }
        
        for item in eligible_list:
            employee = item['employee']
            eligibility = item['eligibility']
            
            try:
                with transaction.atomic():
                    new_grade = eligibility['next_grade']
                    
                    # حساب الرقم الاستدلالي الجديد
                    new_index = None
                    if not override_index:
                        # محاولة الحصول على الرقم الاستدلالي من الشبكة
                        scale_item = GradeScaleItem.objects.filter(
                            version__is_current=True,
                            category=eligibility.get("rule").category if eligibility.get("rule") else EmployeeGradeHistory.objects.filter(employee=employee).first().category,
                            grade_number=new_grade
                        ).first()
                        
                        if scale_item:
                            new_index = scale_item.index_value
                        else:
                            # قيمة افتراضية إذا لم توجد شبكة
                            new_index = eligibility.get('new_index', 0)
                    else:
                        new_index = override_index
                    
                    if new_index is None:
                        raise ValueError(f"لم يتم العثور على رقم استدلالي للدرجة {new_grade}")
                    
                    # إضافة الموظف للترقية
                    record = PromotionService.add_employee_to_promotion(
                        decision=decision,
                        employee=employee,
                        new_grade=new_grade,
                        new_index=new_index,
                        notes=f"ترقية آلية - أقدمية: {eligibility['seniority_years']} سنوات و{eligibility['seniority_months']} أشهر"
                    )
                    
                    results['success'].append({
                        'employee': employee,
                        'record': record
                    })
                    
            except Exception as e:
                results['failed'].append({
                    'employee': employee,
                    'error': str(e)
                })
        
        return results
