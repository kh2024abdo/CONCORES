"""
Serializers للتطبيق Grades/Promotions
"""
from rest_framework import serializers
from django.utils.translation import gettext_lazy as _

from grades.models import (
    RankBody, Category, GradeScaleVersion, GradeScaleItem, Rank,
    PromotionRule, PromotionDecision, PromotionRecord
)


class RankBodySerializer(serializers.ModelSerializer):
    class Meta:
        model = RankBody
        fields = '__all__'


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class GradeScaleVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = GradeScaleVersion
        fields = '__all__'


class GradeScaleItemSerializer(serializers.ModelSerializer):
    category_name_ar = serializers.CharField(source='category.name_ar', read_only=True)
    category_name_fr = serializers.CharField(source='category.name_fr', read_only=True)
    
    class Meta:
        model = GradeScaleItem
        fields = '__all__'


class RankSerializer(serializers.ModelSerializer):
    body_name = serializers.CharField(source='body.name_ar', read_only=True)
    category_name = serializers.CharField(source='category.name_ar', read_only=True)
    category_code = serializers.CharField(source='category.code', read_only=True)
    
    class Meta:
        model = Rank
        fields = '__all__'


class PromotionRuleSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name_ar', read_only=True)
    
    class Meta:
        model = PromotionRule
        fields = '__all__'


class PromotionDecisionSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.full_name', read_only=True)
    records_count = serializers.SerializerMethodField()
    
    class Meta:
        model = PromotionDecision
        fields = '__all__'
    
    def get_records_count(self, obj):
        return obj.records.count()


class PromotionDecisionDetailSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.full_name', read_only=True)
    records = serializers.SerializerMethodField()
    
    class Meta:
        model = PromotionDecision
        fields = '__all__'
    
    def get_records(self, obj):
        records = obj.records.all()[:10]  # أول 10 سجلات فقط
        return PromotionRecordBriefSerializer(records, many=True).data


class PromotionRecordBriefSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    employee_matricule = serializers.CharField(source='employee.matricule', read_only=True)
    
    class Meta:
        model = PromotionRecord
        fields = ['id', 'employee_name', 'employee_matricule', 'previous_grade', 'new_grade', 'new_index']


class PromotionRecordSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    employee_matricule = serializers.CharField(source='employee.matricule', read_only=True)
    employee_rank = serializers.CharField(source='employee.rank.name_ar', read_only=True)
    decision_reference = serializers.CharField(source='decision.reference_number', read_only=True)
    
    class Meta:
        model = PromotionRecord
        fields = '__all__'


class PromotionEligibilitySerializer(serializers.Serializer):
    """
    Serializer لعرض نتيجة أهلية الترقية
    """
    employee_id = serializers.IntegerField()
    employee_name = serializers.CharField()
    employee_matricule = serializers.CharField()
    current_grade = serializers.IntegerField()
    next_grade = serializers.IntegerField()
    seniority_years = serializers.IntegerField()
    seniority_months = serializers.IntegerField()
    seniority_days = serializers.IntegerField()
    required_months = serializers.FloatField()
    days_remaining = serializers.IntegerField()
    status = serializers.CharField()
    next_promotion_date = serializers.DateField(allow_null=True)
    eligible = serializers.BooleanField()
    notes = serializers.ListField(child=serializers.CharField())


class PromotionBatchRequestSerializer(serializers.Serializer):
    """
    Serializer لطلب ترقية جماعية
    """
    reference_number = serializers.CharField(max_length=50)
    decision_date = serializers.DateField()
    effective_date = serializers.DateField()
    description = serializers.CharField(required=False, allow_blank=True)
    employee_ids = serializers.ListField(child=serializers.IntegerField())
    
    def validate_employee_ids(self, value):
        if not value:
            raise serializers.ValidationError("يجب اختيار موظف واحد على الأقل")
        return value
