from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import ReferenceModel, TimeStampedModel

class RankBody(ReferenceModel):
    """
    السلك المهني (Corps)
    مثال: سلك الأساتذة، سلك الإداريين، سلك التقنيين
    """
    code = models.CharField(_("Code"), max_length=20, unique=True)
    description = models.TextField(_("Description"), blank=True)
    is_active = models.BooleanField(_("Active"), default=True)

    class Meta:
        verbose_name = _("Rank Body")
        verbose_name_plural = _("Rank Bodies")
        ordering = ['name_ar']

    def __str__(self):
        return self.name_ar or self.name_fr or self.code


class Category(ReferenceModel):
    """
    الصنف (Category)
    يرتبط بالصنف الإداري (مثلاً: صنف 10، صنف 12...)
    """
    code = models.CharField(_("Code"), max_length=10, unique=True)
    order = models.PositiveIntegerField(_("Order"), help_text=_("Used for sorting"))
    is_active = models.BooleanField(_("Active"), default=True)

    class Meta:
        verbose_name = _("Category")
        verbose_name_plural = _("Categories")
        ordering = ['order']

    def __str__(self):
        return f"{self.code} - {self.name_ar or self.name_fr}"


class GradeScaleVersion(TimeStampedModel):
    """
    إصدار شبكة الأرقام الاستدلالية
    يسمح بتخزين شبكات قديمة وحديثة مع تواريخ السريان
    """
    name = models.CharField(_("Name"), max_length=100)
    effective_from = models.DateField(_("Effective From"))
    effective_to = models.DateField(_("Effective To"), null=True, blank=True)
    is_current = models.BooleanField(_("Is Current"), default=True)
    description = models.TextField(_("Description"), blank=True)

    class Meta:
        verbose_name = _("Grade Scale Version")
        verbose_name_plural = _("Grade Scale Versions")
        ordering = ['-effective_from']

    def __str__(self):
        return f"{self.name} ({self.effective_from})"

    def save(self, *args, **kwargs):
        if self.is_current:
            # جعل الإصدارات الأخرى غير حالية
            GradeScaleVersion.objects.filter(is_current=True).exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)


class GradeScaleItem(models.Model):
    """
    عنصر في شبكة الأرقام الاستدلالية
    يربط الصنف + الدرجة + الإصدار بالرقم الاستدلالي
    """
    version = models.ForeignKey(GradeScaleVersion, on_delete=models.CASCADE, related_name='items')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='scale_items')
    grade_number = models.PositiveIntegerField(_("Grade Number")) # 1 to 13+
    index_value = models.DecimalField(_("Index Value"), max_digits=6, decimal_places=2)
    
    class Meta:
        verbose_name = _("Grade Scale Item")
        verbose_name_plural = _("Grade Scale Items")
        unique_together = ['version', 'category', 'grade_number']
        ordering = ['category__order', 'grade_number']

    def __str__(self):
        return f"{self.category.code} - Grade {self.grade_number}: {self.index_value}"


class Rank(ReferenceModel):
    """
    الرتبة (Rank)
    ترتبط بالسلك والصنف
    """
    body = models.ForeignKey(RankBody, on_delete=models.CASCADE, related_name='ranks', verbose_name=_("Rank Body"))
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='ranks', verbose_name=_("Category"))
    code = models.CharField(_("Code"), max_length=20, unique=True)
    min_grade = models.PositiveIntegerField(_("Min Grade"), default=1)
    max_grade = models.PositiveIntegerField(_("Max Grade"), default=13)
    is_active = models.BooleanField(_("Active"), default=True)

    class Meta:
        verbose_name = _("Rank")
        verbose_name_plural = _("Ranks")
        ordering = ['body', 'category', 'name_ar']
        constraints = [
            models.UniqueConstraint(fields=['body', 'category', 'code'], name='unique_body_category_code')
        ]

    def __str__(self):
        return f"{self.name_ar or self.name_fr} ({self.body.code})"


class PromotionRule(models.Model):
    """
    قواعد الترقية الآلية.
    تحدد المدة الدنيا في الدرجة الحالية للترقية للدرجة التالية.
    """
    from_grade_number = models.PositiveIntegerField(_("From Grade Number"))
    to_grade_number = models.PositiveIntegerField(_("To Grade Number"))
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='promotion_rules')
    
    min_duration_months = models.IntegerField(_("Minimum Duration (Months)"), default=12)
    min_duration_days = models.IntegerField(_("Minimum Duration (Days)"), default=0)
    
    # شروط إضافية (قابلة للتوسع)
    requires_training = models.BooleanField(_("Requires Training"), default=False)
    requires_exam = models.BooleanField(_("Requires Exam"), default=False)
    max_age_limit = models.IntegerField(_("Max Age Limit"), null=True, blank=True)
    
    is_active = models.BooleanField(_("Is Active"), default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Promotion Rule")
        verbose_name_plural = _("Promotion Rules")
        unique_together = ('from_grade_number', 'to_grade_number', 'category')
        ordering = ['category', 'from_grade_number']

    def __str__(self):
        return f"Cat {self.category.code}: Grade {self.from_grade_number} → {self.to_grade_number} ({self.min_duration_months}m)"


class PromotionDecision(models.Model):
    """
    قرار الترقية الجماعي أو الفردي.
    """
    STATUS_CHOICES = [
        ('draft', _('Draft')),
        ('pending', _('Pending Approval')),
        ('approved', _('Approved')),
        ('published', _('Published')),
        ('cancelled', _('Cancelled')),
    ]

    reference_number = models.CharField(_("Reference Number"), max_length=50, unique=True)
    decision_date = models.DateField(_("Decision Date"))
    effective_date = models.DateField(_("Effective Date"))
    status = models.CharField(_("Status"), max_length=20, choices=STATUS_CHOICES, default='draft')
    description = models.TextField(_("Description"), blank=True)
    document = models.FileField(_("Decision Document"), upload_to='promotions/decisions/', null=True, blank=True)
    
    created_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, related_name='created_promotions')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Promotion Decision")
        verbose_name_plural = _("Promotion Decisions")
        ordering = ['-decision_date']

    def __str__(self):
        return f"{self.reference_number} - {self.decision_date}"


class PromotionRecord(models.Model):
    """
    سجل الترقية الفعلي للموظف (يربط الموظف بقرار الترقية).
    هذا السجل ينشئ تلقائيًا سجل درجة جديد (GradeHistory).
    """
    employee = models.ForeignKey('employees.Employee', on_delete=models.CASCADE, related_name='promotion_records')
    decision = models.ForeignKey(PromotionDecision, on_delete=models.CASCADE, related_name='records', null=True, blank=True)
    
    previous_grade = models.PositiveIntegerField(_("Previous Grade"))
    new_grade = models.PositiveIntegerField(_("New Grade"))
    previous_index = models.DecimalField(_("Previous Index"), max_digits=6, decimal_places=2, null=True)
    new_index = models.DecimalField(_("New Index"), max_digits=6, decimal_places=2)
    
    seniority_years = models.IntegerField(_("Seniority Years"), default=0)
    seniority_months = models.IntegerField(_("Seniority Months"), default=0)
    seniority_days = models.IntegerField(_("Seniority Days"), default=0)
    
    notes = models.TextField(_("Notes"), blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Promotion Record")
        verbose_name_plural = _("Promotion Records")
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.employee.full_name} - Grade {self.previous_grade} → {self.new_grade}"
