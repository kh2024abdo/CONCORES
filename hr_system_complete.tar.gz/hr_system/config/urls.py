"""
URL configuration for HR Career Management System.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView

# API URL prefix
API_PREFIX = 'api/v1/'

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API Documentation
    path(f'{API_PREFIX}schema/', SpectacularAPIView.as_view(), name='schema'),
    path(f'{API_PREFIX}swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path(f'{API_PREFIX}redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    
    # Health check
    path('health/', TemplateView.as_view(template_name='health.html'), name='health'),
    
    # API endpoints
    path(f'{API_PREFIX}auth/', include('accounts.urls')),
    path(f'{API_PREFIX}employees/', include('employees.urls')),
    path(f'{API_PREFIX}organization/', include('organization.urls')),
    path(f'{API_PREFIX}career/', include('career.urls')),
    path(f'{API_PREFIX}grades/', include('grades.urls')),
    path(f'{API_PREFIX}positions/', include('positions.urls')),
    path(f'{API_PREFIX}leaves/', include('leaves.urls')),
    path(f'{API_PREFIX}legal-status/', include('legal_status.urls')),
    path(f'{API_PREFIX}senior-positions/', include('senior_positions.urls')),
    path(f'{API_PREFIX}promotions/', include('promotions.urls')),
    path(f'{API_PREFIX}notifications/', include('notifications.urls')),
    path(f'{API_PREFIX}messages/', include('messaging.urls')),
    path(f'{API_PREFIX}reports/', include('reports.urls')),
    path(f'{API_PREFIX}audit/', include('audit.urls')),
    path(f'{API_PREFIX}imports/', include('imports.urls')),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Custom error pages
handler404 = 'core.views.error_404'
handler500 = 'core.views.error_500'
