"""
HR Career Management & Promotion System

Django project configuration.
"""

# This will make celery load the Django settings
from .celery import app as celery_app

__all__ = ('celery_app',)
