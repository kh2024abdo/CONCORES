# نظام تسيير المسار المهني وترقيات الموظفين

## HR Career Management & Promotion System

### Institutional Enterprise HR Platform

---

## نظرة عامة

نظام ويب مؤسسي احترافي مبني بـ Django لإدارة الموظفين ومتابعة مسارهم المهني، مصمم خصيصًا للمؤسسات العمومية والدولة.

### المميزات الرئيسية

- إدارة شاملة للموظفين والملفات الإدارية
- متابعة الرتب والمسار الوظيفي
- نظام ترقيات الدرجات والرتب الآلي
- حساب تاريخ الترقية القادمة والمستحقين
- إدارة الأسلاك والرتب والأصناف والدرجات
- إدارة الهيكل التنظيمي (مديريات/كليات/مصالح)
- إدارة التوجيهات ومناصب العمل
- نظام الإجازات وحساب الأرصدة
- الوضعيات القانونية للموظفين
- المناصب العليا
- سجل المسار المهني الكامل (Timeline)
- إنشاء المقررات والوثائق والتقارير
- تنبيهات مواعيد الترقية
- نظام مراسلة داخلي
- صلاحيات وأدوار متقدمة
- Audit Log شامل
- REST API كامل (API First)
- دعم متعدد اللغات (AR/FR/EN)
- استيراد Excel مع Validation
- قابل للتوسع لنظام موارد بشرية شامل

---

## البنية المعمارية

### Modular Architecture

```
hr_system/
├── core/                 # Core functionality, settings, base classes
├── accounts/             # Users, roles, permissions, authentication
├── employees/            # Employee master data
├── organization/         # Organizational structure
├── career/               # Career path, ranks, grades
├── grades/               # Grade scales, index values
├── positions/            # Positions, assignments
├── leaves/               # Leave management
├── legal_status/         # Legal status tracking
├── senior_positions/     # Senior positions
├── promotions/           # Promotion engine
├── notifications/        # Notifications system
├── messaging/            # Internal messaging
├── reports/              # Report builder
├── audit/                # Audit logging
├── api/                  # API versioning and routing
├── imports/              # Excel import/export
└── settings/             # Project settings
```

### Layered Architecture

```
┌─────────────────────────────────────┐
│         Presentation Layer          │
│  (Templates, HTMX, AJAX, UI)        │
├─────────────────────────────────────┤
│         API Layer                   │
│  (DRF ViewSets, Serializers)        │
├─────────────────────────────────────┤
│         Service Layer               │
│  (Business Logic, Calculators)      │
├─────────────────────────────────────┤
│         Repository Layer            │
│  (Models, QuerySets, Managers)      │
├─────────────────────────────────────┤
│         Database Layer              │
│  (PostgreSQL, Redis)                │
└─────────────────────────────────────┘
```

---

## قاعدة البيانات

### ERD - Entity Relationship Diagram

#### Reference Data

```
┌─────────────────┐       ┌─────────────────┐
│   RankBody      │       │   Category      │
│   (Corps)       │       │   (صنف)         │
├─────────────────┤       ├─────────────────┤
│ id              │       │ id              │
│ code            │       │ code            │
│ name_ar         │       │ number          │
│ name_fr         │       │ name_ar         │
│ name_en         │       │ name_fr         │
│ description     │       │ name_en         │
│ is_active       │       │ index_value     │
└─────────────────┘       └─────────────────┘
         │                        │
         │                        │
         ▼                        ▼
┌─────────────────────────────────────────┐
│              Rank                       │
│              (الرتبة)                    │
├─────────────────────────────────────────┤
│ id                                      │
│ rank_body (FK → RankBody)               │
│ category (FK → Category)                │
│ code                                    │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ is_active                               │
└─────────────────────────────────────────┘
```

#### Grade System

```
┌─────────────────┐       ┌─────────────────────┐
│    Grade        │       │  IndexScaleVersion  │
├─────────────────┤       ├─────────────────────┤
│ id              │       │ id                  │
│ number          │       │ effective_from      │
│ name_ar         │       │ effective_to        │
│ name_fr         │       │ is_current          │
│ name_en         │       └─────────────────────┘
│ min_category    │                │
│ max_category    │                │
│ is_active       │                ▼
└─────────────────┘       ┌─────────────────────┐
                          │   IndexValue        │
                          ├─────────────────────┤
                          │ id                  │
                          │ scale_version (FK)  │
                          │ category (FK)       │
                          │ grade (FK)          │
                          │ index_value         │
                          └─────────────────────┘
```

#### Organization

```
┌─────────────────────────────────────────┐
│         Institution                     │
│         (المؤسسة)                        │
├─────────────────────────────────────────┤
│ id                                      │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ code                                    │
│ logo                                    │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│         Structure                       │
│         (هيكل تنظيمي)                    │
├─────────────────────────────────────────┤
│ id                                      │
│ parent (FK → Structure, nullable)       │
│ institution (FK → Institution)          │
│ type (DIRECTORATE/FACULTY/DEPT/SERVICE) │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ code                                    │
│ is_active                               │
└─────────────────────────────────────────┘
```

#### Employee Core

```
┌─────────────────────────────────────────┐
│            Employee                     │
│            (الموظف)                      │
├─────────────────────────────────────────┤
│ id (PK)                                 │
│ nin (Unique)                            │
│ matricule (Unique)                      │
│ first_name                              │
│ last_name                               │
│ first_name_ar                           │
│ last_name_ar                            │
│ first_name_fr                           │
│ last_name_fr                            │
│ gender                                  │
│ birth_date                              │
│ birth_place                             │
│ birth_place_ar                          │
│ nationality                             │
│ marital_status                          │
│ blood_type                              │
│ father_name                             │
│ mother_name                             │
│ national_service                        │
│ recruitment_date                        │
│ installation_date                       │
│ social_security_number                  │
│ affiliation_date                        │
│ email                                   │
│ phone                                   │
│ address                                 │
│ photo                                   │
│ rfid_card                               │
│ is_active                               │
│ created_at                              │
│ updated_at                              │
│ created_by (FK → User)                  │
│ updated_by (FK → User)                  │
└─────────────────────────────────────────┘
```

#### Career History

```
┌─────────────────────────────────────────┐
│         EmployeeRank                    │
│         (مسار الرتب)                      │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ rank (FK → Rank)                        │
│ start_date                              │
│ end_date (nullable)                     │
│ is_current                              │
│ decision_number                         │
│ decision_date                           │
│ document                                │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         EmployeeGrade                   │
│         (مسار الدرجات)                    │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ grade (FK → Grade)                      │
│ category (FK → Category)                │
│ index_value                             │
│ start_date                              │
│ end_date (nullable)                     │
│ is_current                              │
│ promotion_type                          │
│ decision_number                         │
│ decision_date                           │
│ document                                │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Assignment                      │
│         (التوجيه)                        │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ structure (FK → Structure)              │
│ position (FK → Position, nullable)      │
│ start_date                              │
│ end_date (nullable)                     │
│ is_current                              │
│ movement_type                           │
│ decision_number                         │
│ decision_date                           │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘
```

#### Leaves & Legal Status

```
┌─────────────────────────────────────────┐
│         LeaveType                       │
│         (نوع الإجازة)                     │
├─────────────────────────────────────────┤
│ id                                      │
│ code                                    │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ is_paid                                 │
│ requires_document                       │
│ is_active                               │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Leave                           │
│         (الإجازة)                        │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ leave_type (FK → LeaveType)             │
│ start_date                              │
│ end_date                                │
│ days_count                              │
│ year                                    │
│ balance_before                          │
│ balance_after                           │
│ decision_number                         │
│ decision_date                           │
│ document                                │
│ status                                  │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         LegalStatusType                 │
│         (نوع الوضعية)                     │
├─────────────────────────────────────────┤
│ id                                      │
│ code                                    │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ affects_seniority                       │
│ is_active                               │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         LegalStatus                     │
│         (الوضعية القانونية)               │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ status_type (FK → LegalStatusType)      │
│ start_date                              │
│ end_date (nullable)                     │
│ is_current                              │
│ legal_reference                         │
│ decision_number                         │
│ decision_date                           │
│ document                                │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘
```

#### Senior Positions & Promotions

```
┌─────────────────────────────────────────┐
│         SeniorPosition                  │
│         (منصب عالي)                       │
├─────────────────────────────────────────┤
│ id                                      │
│ name_ar                                 │
│ name_fr                                 │
│ name_en                                 │
│ structure (FK → Structure)              │
│ level                                   │
│ is_active                               │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         EmployeeSeniorPosition          │
│         (شغل منصب عالي)                   │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ senior_position (FK → SeniorPosition)   │
│ start_date                              │
│ end_date (nullable)                     │
│ is_current                              │
│ appointment_decision                    │
│ appointment_date                        │
│ document                                │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Promotion                       │
│         (ترقية)                          │
├─────────────────────────────────────────┤
│ id                                      │
│ employee (FK → Employee)                │
│ from_grade (FK → Grade)                 │
│ to_grade (FK → Grade)                   │
│ from_category (FK → Category)           │
│ to_category (FK → Category)             │
│ promotion_date                          │
│ eligibility_date                        │
│ delay_days                              │
│ promotion_type                          │
│ status (PENDING/APPROVED/REJECTED)      │
│ batch_id (nullable)                     │
│ decision_number                         │
│ decision_date                           │
│ document                                │
│ notes                                   │
│ created_by                              │
│ updated_by                              │
└─────────────────────────────────────────┘
```

#### Accounts & Permissions

```
┌─────────────────────────────────────────┐
│            User                         │
│            (المستخدم)                    │
├─────────────────────────────────────────┤
│ id (PK)                                 │
│ username (Unique)                       │
│ email (Unique)                          │
│ password                                │
│ first_name                              │
│ last_name                               │
│ is_active                               │
│ is_staff                                │
│ is_superuser                            │
│ date_joined                             │
│ last_login                              │
│ created_at                              │
│ updated_at                              │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│            Role                         │
│            (الدور)                       │
├─────────────────────────────────────────┤
│ id                                      │
│ name                                    │
│ description                             │
│ is_system                               │
│ created_at                              │
│ updated_at                              │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│         UserRole                        │
│         (مستخدم-دور)                     │
├─────────────────────────────────────────┤
│ id                                      │
│ user (FK → User)                        │
│ role (FK → Role)                        │
│ assigned_at                             │
│ assigned_by                             │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Permission                      │
│         (الصلاحية)                       │
├─────────────────────────────────────────┤
│ id                                      │
│ codename                                │
│ name                                    │
│ content_type                            │
│ resource                                │
│ action (VIEW/ADD/CHANGE/DELETE/EXPORT)  │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│         RolePermission                  │
│         (دور-صلاحية)                     │
├─────────────────────────────────────────┤
│ id                                      │
│ role (FK → Role)                        │
│ permission (FK → Permission)            │
└─────────────────────────────────────────┘
```

#### Audit & Notifications

```
┌─────────────────────────────────────────┐
│         AuditLog                        │
│         (سجل التدقيق)                     │
├─────────────────────────────────────────┤
│ id                                      │
│ timestamp                               │
│ user (FK → User, nullable)              │
│ action (CREATE/UPDATE/DELETE/LOGIN/...) │
│ ip_address                              │
│ user_agent                              │
│ content_type                            │
│ object_id                               │
│ object_repr                             │
│ changes (JSON)                          │
│ result (SUCCESS/FAILURE)                │
│ error_message                           │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Notification                    │
│         (إشعار)                          │
├─────────────────────────────────────────┤
│ id                                      │
│ recipient (FK → User)                   │
│ notification_type                       │
│ title                                   │
│ message                                 │
│ data (JSON)                             │
│ is_read                                 │
│ read_at                                 │
│ created_at                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         Message                         │
│         (رسالة)                          │
├─────────────────────────────────────────┤
│ id                                      │
│ sender (FK → User)                      │
│ recipient (FK → User)                   │
│ subject                                 │
│ body                                    │
│ attachment                              │
│ is_read                                 │
│ read_at                                 │
│ sent_at                                 │
└─────────────────────────────────────────┘
```

---

## API Endpoints Structure

```
/api/v1/
├── auth/
│   ├── login/
│   ├── logout/
│   ├── refresh/
│   ├── me/
│   └── change-password/
│
├── employees/
│   ├── /                           # List/Create
│   ├──/{id}/                       # Retrieve/Update/Delete
│   ├──/{id}/career/                # Career history
│   ├──/{id}/grades/                # Grade history
│   ├──/{id}/ranks/                 # Rank history
│   ├──/{id}/assignments/           # Assignments
│   ├──/{id}/leaves/                # Leaves
│   ├──/{id}/legal-status/          # Legal status
│   ├──/{id}/senior-positions/      # Senior positions
│   └──/{id}/timeline/              # Timeline view
│
├── promotions/
│   ├── /                           # List/Create
│   ├──/{id}/
│   ├── eligible/                   # Eligible employees
│   ├── upcoming/                   # Upcoming promotions
│   └── calculate/                  # Calculate promotions
│
├── organization/
│   ├── structures/
│   ├── institutions/
│   └── positions/
│
├── reference/
│   ├── rank-bodies/
│   ├── ranks/
│   ├── categories/
│   ├── grades/
│   ├── index-scales/
│   ├── leave-types/
│   └── legal-status-types/
│
├── reports/
│   ├── /
│   ├──/{id}/
│   ├── templates/
│   └── generate/
│
├── notifications/
│   ├── /
│   ├──/{id}/
│   └── mark-read/
│
├── messages/
│   ├── inbox/
│   ├── sent/
│   ├──/{id}/
│   └── send/
│
├── audit/
│   ├── logs/
│   └── login-history/
│
├── imports/
│   ├── employees/
│   └── preview/
│
└── users/
    ├── /
    ├──/{id}/
    ├── roles/
    └── permissions/
```

---

## Services Layer

### Core Services

```python
# career/services.py
class EmployeeService:
    - create_employee()
    - update_employee()
    - get_employee_career()
    - get_current_status()

class CareerService:
    - assign_rank()
    - assign_grade()
    - get_career_history()
    - validate_career_dates()

class PromotionCalculator:
    - calculate_seniority()
    - calculate_eligibility_date()
    - get_next_grade()
    - get_eligible_employees()
    - calculate_delay()
    - check_promotion_conditions()

# leaves/services.py
class LeaveService:
    - request_leave()
    - approve_leave()
    - reject_leave()
    - calculate_balance()
    - get_leave_history()

# organization/services.py
class OrganizationService:
    - create_structure()
    - assign_employee()
    - get_organization_chart()

# reports/services.py
class ReportService:
    - generate_report()
    - export_pdf()
    - export_excel()
    - apply_template()

# imports/services.py
class ImportService:
    - validate_excel()
    - preview_import()
    - execute_import()
    - generate_error_report()
```

---

## Roles & Permissions

### Default Roles

1. **Super Administrator**
   - Full system access
   - Cannot be restricted

2. **HR Administrator**
   - Full HR access
   - User management
   - Configuration

3. **HR Manager**
   - Employee management
   - Promotion approval
   - Reports

4. **HR Officer**
   - Employee data entry
   - Basic operations
   - No deletion rights

5. **Department Manager**
   - View own department employees
   - Request promotions
   - Approve leaves

6. **Viewer**
   - Read-only access
   - Limited data visibility

7. **Auditor**
   - View audit logs
   - Export reports
   - No modification

### Permission Types

```
Resource-based:
- employees
- promotions
- leaves
- reports
- users
- organization
- reference_data

Actions:
- view
- add
- change
- delete
- export
- print
- approve
```

### Object-Level Permissions

```python
# Example: Department-level access
class DepartmentPermission(BasePermission):
    def has_object_permission(self, request, obj):
        if request.user.is_superuser:
            return True
        
        user_dept = request.user.department
        if user_dept:
            return obj.department == user_dept
        
        return False
```

---

## Security Strategy

### Authentication

- JWT Token-based authentication
- Refresh tokens
- Session timeout
- Password policy enforcement
- Brute-force protection

### Authorization

- Role-based access control (RBAC)
- Object-level permissions
- Resource-level permissions
- Backend validation for all operations

### Data Protection

- CSRF protection
- XSS prevention
- SQL injection prevention
- Secure file uploads
- MIME type validation
- File size limits
- Private document serving

### Audit & Logging

- All sensitive operations logged
- Login/logout tracking
- Data change tracking
- Export/print logging
- Immutable audit logs

### Rate Limiting

- API throttling
- Login attempt limits
- Export limits
- Import frequency limits

---

## Excel Import Strategy

### Process Flow

```
1. Upload Excel File
        ↓
2. Validate File Format
        ↓
3. Read & Parse Data
        ↓
4. Field Mapping
        ↓
5. Data Validation
   - NIN duplicates
   - Matricule duplicates
   - Date formats
   - Required fields
   - Reference data existence
        ↓
6. Preview Results
        ↓
7. Error Report Generation
        ↓
8. User Confirmation
        ↓
9. Execute Import
        ↓
10. Import Report
    - Total records
    - Imported
    - Rejected
    - Duplicates
    - Errors
```

### Validation Rules

```python
VALIDATION_RULES = {
    'nin': {
        'required': True,
        'unique': True,
        'format': 'regex_pattern'
    },
    'matricule': {
        'required': True,
        'unique': True
    },
    'birth_date': {
        'required': True,
        'format': 'date',
        'max': 'today'
    },
    'rank': {
        'required': True,
        'exists_in': 'Rank'
    },
    'grade': {
        'required': True,
        'exists_in': 'Grade'
    }
}
```

---

## Report Builder

### Features

- Dynamic field selection
- Custom filters
- Grouping options
- Sorting
- Templates
- Headers/Footers
- Logo support
- Signatures
- Page numbering
- Multiple output formats (PDF, Excel, Print)

### Report Types

1. **Predefined Reports**
   - Promotion eligible list
   - Upcoming promotions
   - Employee by department
   - Employee by rank
   - Leave balance
   - Legal status report

2. **Custom Reports**
   - User-defined fields
   - Custom filters
   - Save as template

### Template System

```python
class ReportTemplate:
    - name
    - description
    - fields (JSON)
    - filters (JSON)
    - grouping (JSON)
    - header_template
    - footer_template
    - logo
    - signature_fields
```

---

## Docker Configuration

### Services

```yaml
version: '3.8'

services:
  web:
    build: .
    command: python manage.py runserver 0.0.0.0:8000
    volumes:
      - .:/app
    ports:
      - "8000:8000"
    env_file:
      - .env
    depends_on:
      - db
      - redis

  db:
    image: postgres:15
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      POSTGRES_DB: hr_system
      POSTGRES_USER: hr_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  worker:
    build: .
    command: celery -A config worker --loglevel=info
    volumes:
      - .:/app
    depends_on:
      - db
      - redis

  beat:
    build: .
    command: celery -A config beat --loglevel=info
    volumes:
      - .:/app
    depends_on:
      - db
      - redis

volumes:
  postgres_data:
```

---

## Testing Strategy

### Test Coverage

1. **Model Tests**
   - Field validation
   - Relationships
   - Constraints
   - Methods

2. **Service Tests**
   - Business logic
   - Promotion calculations
   - Leave calculations
   - Import validation

3. **API Tests**
   - Endpoints
   - Authentication
   - Permissions
   - Serialization
   - Filtering/Pagination

4. **Permission Tests**
   - Role-based access
   - Object-level permissions
   - Edge cases

5. **Integration Tests**
   - Full workflows
   - Import process
   - Report generation

### Example: Promotion Calculator Tests

```python
class PromotionCalculatorTest(TestCase):
    def test_calculate_seniority_basic(self):
        # Test basic seniority calculation
        
    def test_calculate_seniority_with_leave(self):
        # Test with leave periods
        
    def test_calculate_eligibility_date(self):
        # Test eligibility date
        
    def test_get_eligible_employees(self):
        # Test eligible employees list
        
    def test_promotion_delay(self):
        # Test delay calculation
```

---

## Implementation Phases

### Phase 1: Foundation
- [x] Project architecture
- [x] Docker setup
- [x] PostgreSQL configuration
- [x] Base settings
- [ ] Core models

### Phase 2: Accounts & Auth
- [ ] User model
- [ ] Role system
- [ ] Permission system
- [ ] JWT authentication
- [ ] Login/Logout

### Phase 3: Organization
- [ ] Institution
- [ ] Structure
- [ ] Positions

### Phase 4: Employees
- [ ] Employee model
- [ ] Employee CRUD
- [ ] Employee search/filter
- [ ] Master/Detail view

### Phase 5: Career
- [ ] RankBody, Rank
- [ ] Category, Grade
- [ ] IndexScale
- [ ] EmployeeRank
- [ ] EmployeeGrade
- [ ] Assignment

### Phase 6: Promotion Engine
- [ ] PromotionCalculator service
- [ ] Eligibility calculation
- [ ] Promotion records
- [ ] Promotion lists

### Phase 7: Leaves & Legal Status
- [ ] LeaveType, Leave
- [ ] LegalStatusType, LegalStatus
- [ ] Balance calculation

### Phase 8: Senior Positions
- [ ] SeniorPosition model
- [ ] EmployeeSeniorPosition

### Phase 9: Documents
- [ ] Document model
- [ ] Decision model
- [ ] File upload

### Phase 10: Reports
- [ ] Report builder
- [ ] Templates
- [ ] PDF/Excel export

### Phase 11: Notifications & Messaging
- [ ] Notification system
- [ ] Message system

### Phase 12: Audit & Security
- [ ] Audit logging
- [ ] Login history
- [ ] Security hardening

### Phase 13: Import/Export
- [ ] Excel import
- [ ] Validation
- [ ] Export functions

### Phase 14: API Documentation
- [ ] OpenAPI schema
- [ ] Swagger UI
- [ ] ReDoc

### Phase 15: Testing & Production
- [ ] Unit tests
- [ ] Integration tests
- [ ] Performance optimization
- [ ] Production hardening

---

## Technology Stack

### Backend
- Python 3.11+
- Django 5.x
- Django REST Framework
- PostgreSQL 15
- Redis 7
- Celery (async tasks)

### Frontend
- Django Templates
- HTMX (dynamic updates)
- Alpine.js (interactivity)
- Tailwind CSS (styling)

### DevOps
- Docker
- Docker Compose
- Gunicorn (production)
- Nginx (reverse proxy)

### Testing
- pytest
- pytest-django
- factory_boy
- coverage

### Documentation
- Sphinx
- drf-spectacular (OpenAPI)

---

## Next Steps

1. Initialize Django project structure
2. Create Docker configuration
3. Set up PostgreSQL
4. Configure settings modules
5. Implement core apps
6. Build reference data models
7. Implement employee management
8. Develop promotion engine
9. Create API endpoints
10. Build professional UI

---

## Contact & Support

للدعم والاستفسارات التقنية حول النظام.

---

**Version:** 1.0.0  
**Last Updated:** 2025  
**License:** Proprietary - Government Use
