from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime


def error_404(request, exception):
    """Custom 404 error handler"""
    return render(request, 'errors/404.html', status=404)


def error_500(request):
    """Custom 500 error handler"""
    return render(request, 'errors/500.html', status=500)


@api_view(['GET'])
def health_check(request):
    """Health check endpoint for API"""
    return Response({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'service': 'HR Career Management System'
    }, status=status.HTTP_200_OK)
