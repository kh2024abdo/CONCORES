from django.db import models
from django.utils.translation import gettext_lazy as _


class TimeStampedModel(models.Model):
    """
    Abstract base model with created_at and updated_at fields.
    All models should inherit from this to track creation and modification times.
    """
    created_at = models.DateTimeField(
        _('created at'),
        auto_now_add=True,
        help_text=_('Date and time when the record was created')
    )
    updated_at = models.DateTimeField(
        _('updated at'),
        auto_now=True,
        help_text=_('Date and time when the record was last updated')
    )

    class Meta:
        abstract = True
        ordering = ['-created_at']


class AuditedModel(TimeStampedModel):
    """
    Abstract base model with audit fields.
    Tracks who created and modified the record.
    """
    created_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_created',
        verbose_name=_('created by'),
        help_text=_('User who created this record')
    )
    updated_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_updated',
        verbose_name=_('updated by'),
        help_text=_('User who last updated this record')
    )

    class Meta:
        abstract = True


class SoftDeleteModel(AuditedModel):
    """
    Abstract base model with soft delete capability.
    Instead of deleting records, mark them as deleted.
    """
    is_deleted = models.BooleanField(
        _('is deleted'),
        default=False,
        help_text=_('Soft delete flag')
    )
    deleted_at = models.DateTimeField(
        _('deleted at'),
        null=True,
        blank=True,
        help_text=_('Date and time when the record was soft deleted')
    )
    deleted_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='%(class)s_deleted',
        verbose_name=_('deleted by'),
        help_text=_('User who deleted this record')
    )

    class Meta:
        abstract = True

    def delete(self, using=None, keep_parents=False, hard=False):
        """
        Soft delete by default. Set hard=True for actual deletion.
        """
        if hard:
            return super().delete(using=using, keep_parents=keep_parents)
        
        from django.utils import timezone
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save(update_fields=['is_deleted', 'deleted_at', 'updated_at'])
        return None

    def restore(self):
        """
        Restore a soft-deleted record.
        """
        self.is_deleted = False
        self.deleted_at = None
        self.save(update_fields=['is_deleted', 'deleted_at', 'updated_at'])


class ActiveManager(models.Manager):
    """
    Manager that filters out soft-deleted records by default.
    """
    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)


class AllObjectsManager(models.Manager):
    """
    Manager that returns all records including soft-deleted ones.
    """
    def get_queryset(self):
        return super().get_queryset()


class ReferenceModel(TimeStampedModel):
    """
    Abstract base model for reference data (ranks, categories, etc.).
    Supports multilingual names and active/inactive status.
    """
    code = models.CharField(
        _('code'),
        max_length=50,
        unique=True,
        help_text=_('Unique code for this reference')
    )
    name_ar = models.CharField(
        _('name (Arabic)'),
        max_length=200,
        help_text=_('Name in Arabic')
    )
    name_fr = models.CharField(
        _('name (French)'),
        max_length=200,
        help_text=_('Name in French')
    )
    name_en = models.CharField(
        _('name (English)'),
        max_length=200,
        help_text=_('Name in English')
    )
    description_ar = models.TextField(
        _('description (Arabic)'),
        blank=True,
        null=True
    )
    description_fr = models.TextField(
        _('description (French)'),
        blank=True,
        null=True
    )
    description_en = models.TextField(
        _('description (English)'),
        blank=True,
        null=True
    )
    is_active = models.BooleanField(
        _('is active'),
        default=True,
        help_text=_('Whether this reference is active')
    )
    order = models.PositiveIntegerField(
        _('order'),
        default=0,
        help_text=_('Display order')
    )

    class Meta:
        abstract = True
        ordering = ['order', 'code']

    def __str__(self):
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar':
            return self.name_ar
        elif lang == 'fr':
            return self.name_fr
        return self.name_en or self.name_ar

    @property
    def display_name(self):
        """Get name based on current language"""
        from django.utils.translation import get_language
        lang = get_language()
        if lang == 'ar':
            return self.name_ar
        elif lang == 'fr':
            return self.name_fr
        return self.name_en or self.name_ar
