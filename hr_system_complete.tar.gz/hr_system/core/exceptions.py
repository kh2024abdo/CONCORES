from rest_framework.views import exception_handler
from rest_framework.exceptions import APIException
from django.utils.translation import gettext_lazy as _
import logging

logger = logging.getLogger('audit')


class CustomAPIException(APIException):
    """
    Base custom API exception with user-friendly messages.
    """
    status_code = 500
    default_detail = _('An error occurred. Please try again later.')
    default_code = 'error'

    def __init__(self, detail=None, code=None, status_code=None):
        if detail is None:
            detail = self.default_detail
        if code is None:
            code = self.default_code
        if status_code is not None:
            self.status_code = status_code
        super().__init__(detail, code)


class ValidationError(CustomAPIException):
    """
    Validation error for business logic violations.
    """
    status_code = 400
    default_detail = _('Validation error.')
    default_code = 'validation_error'


class NotFoundError(CustomAPIException):
    """
    Resource not found error.
    """
    status_code = 404
    default_detail = _('Resource not found.')
    default_code = 'not_found'


class PermissionDeniedError(CustomAPIException):
    """
    Permission denied error.
    """
    status_code = 403
    default_detail = _('You do not have permission to perform this action.')
    default_code = 'permission_denied'


class AuthenticationError(CustomAPIException):
    """
    Authentication error.
    """
    status_code = 401
    default_detail = _('Authentication credentials were not provided or are invalid.')
    default_code = 'authentication_failed'


class ConflictError(CustomAPIException):
    """
    Conflict error (e.g., duplicate record).
    """
    status_code = 409
    default_detail = _('A conflict occurred. The resource already exists.')
    default_code = 'conflict'


class ImportError(CustomAPIException):
    """
    Import error for Excel/data import operations.
    """
    status_code = 400
    default_detail = _('Import failed. Please check your data.')
    default_code = 'import_error'

    def __init__(self, detail=None, errors=None, **kwargs):
        super().__init__(detail, **kwargs)
        self.errors = errors or []


class PromotionError(CustomAPIException):
    """
    Promotion calculation or processing error.
    """
    status_code = 400
    default_detail = _('Promotion operation failed.')
    default_code = 'promotion_error'


def custom_exception_handler(exc, context):
    """
    Custom exception handler for DRF.
    Logs errors and returns user-friendly responses.
    """
    # Call REST framework's default exception handler first
    response = exception_handler(exc, context)

    # If response is None, it's an unhandled exception
    if response is None:
        logger.error(f'Unhandled exception: {str(exc)}', exc_info=True)
        
        # Return a generic error response
        from rest_framework.response import Response
        from rest_framework import status
        
        return Response(
            {
                'error': {
                    'code': 'server_error',
                    'message': _('An internal server error occurred. Please contact support.'),
                    'detail': str(exc) if context['request'].user.is_superuser else None
                }
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
    # Log the error
    if response.status_code >= 500:
        logger.error(f'Server error: {response.data}', exc_info=True)
    elif response.status_code >= 400:
        logger.warning(f'Client error: {response.data}')
    
    # Customize error response format
    if hasattr(response, 'data'):
        if isinstance(response.data, dict):
            # Keep DRF's standard error format but add error wrapper
            response.data = {
                'error': {
                    'code': getattr(exc, 'default_code', 'error'),
                    'message': str(response.data.get('detail', response.data.get('error', 'An error occurred'))),
                    'details': response.data
                }
            }
        elif isinstance(response.data, list):
            # Handle validation errors (list of errors)
            response.data = {
                'error': {
                    'code': 'validation_error',
                    'message': _('Validation failed.'),
                    'details': {'fields': response.data}
                }
            }
    
    return response
